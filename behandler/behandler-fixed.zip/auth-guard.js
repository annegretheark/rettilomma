(function () {
  const loginUrl = "../hestebehandler-login.html";

  function visApp() {
    document.documentElement.removeAttribute("data-auth-pending");
  }

  function tilLogin() {
    localStorage.removeItem("rettilommaValgtModul");
    window.location.replace(loginUrl);
  }

  async function sjekkInnlogging() {
    if (!window.supabaseClient || !window.supabaseClient.auth) {
      tilLogin();
      return;
    }

    const { data, error } = await window.supabaseClient.auth.getSession();
    if (error || !data || !data.session) {
      tilLogin();
      return;
    }

    visApp();

    window.supabaseClient.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_OUT" || !session) tilLogin();
    });
  }

  window.behLoggUt = async function behLoggUt(event) {
    if (event) event.preventDefault();
    localStorage.removeItem("rettilommaValgtModul");
    if (window.supabaseClient && window.supabaseClient.auth) {
      await window.supabaseClient.auth.signOut();
    }
    tilLogin();
    return false;
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", sjekkInnlogging);
  } else {
    sjekkInnlogging();
  }
})();
