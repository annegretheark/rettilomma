/* Sysadmin - Faktura hovslagere */
(function(){
  function $(id){ return document.getElementById(id); }
  function erSysadmin(){
    const email = String(window.innloggetEpost || localStorage.getItem("handInnloggetEpost") || "").toLowerCase();
    return window.erSystemadmin === true || email === "greknuts@online.no";
  }
  function msg(t, feil){
    const el = $("sysadmHovslagerFakturaMelding");
    if (el) { el.textContent = t || ""; el.style.color = feil ? "#fca5a5" : ""; }
  }
  function esc(v){
    return String(v == null ? "" : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function erHovslagerFirma(f){
    const st = String(f.system_type || f.type || "").toLowerCase();
    if (st.includes("hovslager")) return true;
    const m = f.moduler || {};
    if (Array.isArray(m)) return m.includes("hovslager");
    if (typeof m === "object" && m && m.hovslager === true) return true;
    return false;
  }

  async function hentHovslagerFirmaer(){
    if (!window.supabaseClient && typeof supabaseClient === "undefined") return [];
    const { data, error } = await supabaseClient
      .from("hand_firma")
      .select("id, navn, epost, orgnr, system_type, moduler, linknavn")
      .order("navn", { ascending: true });

    if (error) {
      msg("Kunne ikke hente hand_firma: " + error.message, true);
      return [];
    }

    const alle = data || [];
    const filtrert = alle.filter(erHovslagerFirma);
    return filtrert.length ? filtrert : alle.filter(f => String(f.navn || "").toLowerCase().includes("hov"));
  }

  async function fyllHovslagerFirmaValg(){
    const sel = $("sysadmHovslagerFirmaValg");
    if (!sel || !erSysadmin()) return;

    msg("Henter hovslagere...");
    const firmaer = await hentHovslagerFirmaer();

    sel.innerHTML = '<option value="">Velg hovslagerfirma...</option>';
    firmaer.forEach(f => {
      const opt = document.createElement("option");
      opt.value = f.id;
      opt.textContent = f.navn || f.epost || f.id;
      sel.appendChild(opt);
    });

    window.sysadmHovslagerFirmaer = firmaer;

    if (!firmaer.length) {
      msg("Fant ingen hovslagerfirma. Sjekk at hand_firma har system_type='hovslager' eller moduler.hovslager=true.", true);
    } else {
      msg("Fant " + firmaer.length + " hovslagerfirma.");
    }

    tegnListe();
  }

  function valgtFirma(){
    const id = $("sysadmHovslagerFirmaValg")?.value || "";
    return (window.sysadmHovslagerFirmaer || []).find(f => String(f.id) === String(id)) || null;
  }

  function tegnListe(){
    const liste = $("sysadmHovslagerFakturaListe");
    if (!liste) return;
    const firmaer = window.sysadmHovslagerFirmaer || [];

    if (!firmaer.length) {
      liste.innerHTML = "<p>Ingen hovslagere lastet.</p>";
      return;
    }

    liste.innerHTML = '<table><thead><tr><th>Firma</th><th>E-post</th><th>Org.nr</th><th>Type</th></tr></thead><tbody>' +
      firmaer.map(f => '<tr><td>'+esc(f.navn)+'</td><td>'+esc(f.epost)+'</td><td>'+esc(f.orgnr)+'</td><td>'+esc(f.system_type || "hovslager")+'</td></tr>').join("") +
      '</tbody></table>';
  }

  async function lagHovslagerFaktura(){
    if (!erSysadmin()) { alert("Kun sysadmin kan fakturere hovslagere."); return; }
    const firma = valgtFirma();
    if (!firma) { msg("Velg hovslagerfirma først.", true); return; }

    const liste = $("sysadmHovslagerFakturaListe");
    const dato = new Date().toISOString().slice(0,10);
    const fakturanr = "SYS-HOV-" + dato.replaceAll("-", "") + "-" + String(Math.floor(Math.random()*9000+1000));

    if (liste) {
      liste.innerHTML =
        '<div class="kort">' +
        '<h3>Fakturagrunnlag</h3>' +
        '<p><strong>Firma:</strong> ' + esc(firma.navn || "") + '</p>' +
        '<p><strong>E-post:</strong> ' + esc(firma.epost || "") + '</p>' +
        '<p><strong>Org.nr:</strong> ' + esc(firma.orgnr || "") + '</p>' +
        '<p><strong>Fakturanr:</strong> ' + esc(fakturanr) + '</p>' +
        '<p><strong>Dato:</strong> ' + esc(dato) + '</p>' +
        '<p>Dette er et sysadmin fakturagrunnlag for hovslagerkunde. Beløp/pris kan kobles til abonnement/prismodell senere.</p>' +
        '</div>';
    }

    msg("Fakturagrunnlag laget for " + (firma.navn || "valgt hovslager") + ".");
  }

  window.visSysadmHovslagerFakturaSide = async function(){
    if (!erSysadmin()) { alert("Kun sysadmin."); return; }
    if (typeof window.skjulAlleSider === "function") window.skjulAlleSider();
    const app = $("appSide");
    const side = $("sysadmHovslagerFakturaSide");
    if (app) { app.classList.remove("skjult","hidden"); app.style.display = ""; }
    if (side) { side.classList.remove("skjult","hidden"); side.style.display = ""; }
    await fyllHovslagerFirmaValg();
  };

  function bind(){
    const last = $("sysadmHovslagerLastKnapp");
    const lag = $("sysadmHovslagerFakturaKnapp");
    if (last && last.dataset.bound !== "1") {
      last.dataset.bound = "1";
      last.addEventListener("click", fyllHovslagerFirmaValg);
    }
    if (lag && lag.dataset.bound !== "1") {
      lag.dataset.bound = "1";
      lag.addEventListener("click", lagHovslagerFaktura);
    }
  }

  document.addEventListener("handPartialerLastet", function(){ bind(); setTimeout(bind, 200); });
  document.addEventListener("DOMContentLoaded", bind);
  window.addEventListener("load", bind);
})();
