const MVA_SATS = 0.25;

function formatBelop(verdi) {
  return Number(verdi || 0).toLocaleString("no-NO", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function tryggFilnavn(tekst) {
  return String(tekst || "faktura")
    .toLowerCase()
    .replace(/[æ]/g, "ae")
    .replace(/[ø]/g, "o")
    .replace(/[å]/g, "a")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function formatDatoISO(dato) {
  return dato.toISOString().slice(0, 10);
}

function leggTilDager(dato, dager) {
  const nyDato = new Date(dato);
  nyDato.setDate(nyDato.getDate() + dager);
  return nyDato;
}

function hentValgtMaaned() {
  const datoFelt = document.getElementById("dato");
  const dato = datoFelt && datoFelt.value
    ? datoFelt.value
    : new Date().toISOString().slice(0, 10);

  return dato.slice(0, 7);
}

function hentValgtKunde() {
  const kundeValg = document.getElementById("kundeValg");
  if (!kundeValg || !kundeValg.value) return null;

  const valgtId = String(kundeValg.value);

  return (window.kunder || []).find(k =>
    String(k.id || "") === valgtId ||
    String(k.kundenr || "") === valgtId
  ) || null;
}

function hentFirmaFraSkjema() {
  const logo = document.getElementById("firmaLogoPreview")?.src || "";

  return {
    navn: document.getElementById("firmaNavn")?.value || "",
    adresse: document.getElementById("firmaAdresse")?.value || "",
    orgnr: document.getElementById("firmaOrgnr")?.value || "",
    mva_nr: document.getElementById("firmaMvanr")?.value || "",
    telefon: document.getElementById("firmaTelefon")?.value || "",
    epost: document.getElementById("firmaEpost")?.value || "",
    kontonr: document.getElementById("firmaKontonr")?.value || "",
    kontaktperson: document.getElementById("firmaKontaktperson")?.value || "",
    logo: logo && logo.startsWith("data:image") ? logo : ""
  };
}

async function hentFirmaData() {
  try {
    const { data, error } = await supabaseClient
      .from("firma")
      .select("*")
      .order("id", { ascending: true })
      .limit(1)
      .maybeSingle();

    if (error) {
      console.warn("Kunne ikke hente firma fra database:", error);
    }

    const skjemaFirma = hentFirmaFraSkjema();

    return Object.assign({}, skjemaFirma, data || {}, {
      kontonr: (data && (data.kontonr || data.konto_nr)) || skjemaFirma.kontonr || "",
      mva_nr: (data && (data.mva_nr || data.mvanr)) || skjemaFirma.mva_nr || "",
      logo: (data && data.logo) || skjemaFirma.logo || ""
    });
  } catch (e) {
    console.warn("Kunne ikke hente firma fra database:", e);
    return hentFirmaFraSkjema();
  }
}

function hentKundeNr(kunde, time) {
  return String(
    kunde?.kundenr ||
    kunde?.kunde_nr ||
    kunde?.id ||
    time?.kunde_nr ||
    time?.kundeNr ||
    time?.kunde_id ||
    ""
  );
}

function hentKundeNavn(kunde, time) {
  return String(
    kunde?.navn ||
    time?.kunde_navn ||
    time?.kundeNavn ||
    time?.kunde ||
    "Kunde"
  );
}

function finnKundeForTime(time) {
  const kunder = window.kunder || [];

  return kunder.find(k =>
    String(k.id || "") === String(time.kunde_id || "") ||
    String(k.kundenr || "") === String(time.kunde_nr || time.kundeNr || "") ||
    String(k.navn || "").toLowerCase() === String(time.kunde_navn || time.kundeNavn || time.kunde || "").toLowerCase()
  ) || null;
}

function erSammeKunde(time, kunde) {
  if (!kunde) return true;

  return String(time.kunde_id || "") === String(kunde.id || "") ||
    String(time.kunde_nr || time.kundeNr || "") === String(kunde.kundenr || kunde.id || "") ||
    String(time.kunde_navn || time.kundeNavn || time.kunde || "").toLowerCase() === String(kunde.navn || "").toLowerCase();
}

function hentFakturaTimer(kunde = null) {
  const maaned = hentValgtMaaned();
  const valgtKunde = kunde || hentValgtKunde();

  return (window.timer || [])
    .filter(t => t.fakturerbar !== false)
    .filter(t => String(t.dato || "").slice(0, 7) === maaned)
    .filter(t => erSammeKunde(t, valgtKunde));
}

function beregnSumEksMvaForTime(time) {
  if (time.sum !== undefined && time.sum !== null && Number(time.sum) > 0) {
    return Number(time.sum);
  }

  return Number(time.timer || 0) * Number(time.timepris || 0);
}

function beregnMvaLinje(time) {
  const sumEksMva = beregnSumEksMvaForTime(time);
  const mva = sumEksMva * MVA_SATS;
  const sumInkMva = sumEksMva + mva;

  return {
    sumEksMva,
    mva,
    sumInkMva
  };
}

function summerTimerMedMva(timerListe) {
  return timerListe.reduce((acc, t) => {
    const linje = beregnMvaLinje(t);
    acc.sumEksMva += linje.sumEksMva;
    acc.mva += linje.mva;
    acc.sumInkMva += linje.sumInkMva;
    return acc;
  }, { sumEksMva: 0, mva: 0, sumInkMva: 0 });
}

function grupperTimerPerKunde(timerListe) {
  const grupper = new Map();

  timerListe.forEach(t => {
    const kunde = finnKundeForTime(t) || {
      id: t.kunde_id || t.kunde_nr || t.kundeNr || t.kunde_navn || t.kundeNavn || "kunde",
      kundenr: t.kunde_nr || t.kundeNr || t.kunde_id || "",
      navn: t.kunde_navn || t.kundeNavn || t.kunde || "Kunde",
      adresse: "",
      epost: ""
    };

    const key = String(kunde.id || kunde.kundenr || kunde.navn || "kunde");

    if (!grupper.has(key)) {
      grupper.set(key, { kunde, timer: [] });
    }

    grupper.get(key).timer.push(t);
  });

  return Array.from(grupper.values());
}

function hentTimerIGruppeSomIkkeErFakturert(timerListe) {
  return (timerListe || []).filter(t => t.fakturert !== true);
}

function csvVerdi(verdi) {
  const tekst = String(verdi ?? "").replace(/"/g, '""');
  return `"${tekst}"`;
}

function lagMvaCsvForGrupper(grupper, maaned) {
  const kolonner = [
    "kunde_nr",
    "kunde_navn",
    "dato",
    "sum_eks_mva",
    "mva_25",
    "sum_inkl_mva"
  ];

  const rader = [];

  grupper.forEach(gruppe => {
    const timerIkkeFakturert = hentTimerIGruppeSomIkkeErFakturert(gruppe.timer);
    if (!timerIkkeFakturert.length) return;

    const summer = summerTimerMedMva(timerIkkeFakturert);

    rader.push([
      hentKundeNr(gruppe.kunde, timerIkkeFakturert[0]),
      hentKundeNavn(gruppe.kunde, timerIkkeFakturert[0]),
      maaned,
      formatBelop(summer.sumEksMva),
      formatBelop(summer.mva),
      formatBelop(summer.sumInkMva)
    ]);
  });

  if (!rader.length) return false;

  const csv = [kolonner, ...rader]
    .map(rad => rad.map(csvVerdi).join(";"))
    .join("\r\n");

  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");

  a.href = url;
  a.download = `mva_regneark_${maaned}.csv`;

  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  URL.revokeObjectURL(url);

  return true;
}

async function markerTimerSomFakturert(grupper) {
  const ids = grupper
    .flatMap(gruppe => hentTimerIGruppeSomIkkeErFakturert(gruppe.timer))
    .map(t => t.id)
    .filter(Boolean);

  if (!ids.length) return false;

  const { error } = await supabaseClient
    .from("timer")
    .update({
      fakturert: true,
      fakturert_at: new Date().toISOString()
    })
    .in("id", ids);

  if (error) {
    console.error("Faktura ble laget, men timer ble ikke markert som fakturert:", error);
    throw error;
  }

  return true;
}

function leggTilLogo(doc, firma) {
  if (!firma.logo) return false;

  try {
    const props = doc.getImageProperties(firma.logo);
    const maxBredde = 42;
    const maxHoyde = 22;
    let bredde = maxBredde;
    let hoyde = (props.height * bredde) / props.width;

    if (hoyde > maxHoyde) {
      hoyde = maxHoyde;
      bredde = (props.width * hoyde) / props.height;
    }

    doc.addImage(firma.logo, props.fileType || "PNG", 150, 10, bredde, hoyde);
    return true;
  } catch (e) {
    console.warn("Kunne ikke legge logo på faktura:", e);
    return false;
  }
}

function lagEnFakturaPdf(kunde, fakturaTimer, maaned, firma, erKopi = false) {
  const jspdfObj = window.jspdf;
  const doc = new jspdfObj.jsPDF();

  const summer = summerTimerMedMva(fakturaTimer);
  const fakturaDato = new Date();
  const forfallsDato = leggTilDager(fakturaDato, 14);

  let y = 15;

  leggTilLogo(doc, firma);

  doc.setFontSize(18);
  doc.text("Faktura", 14, y);

  if (erKopi) {
    doc.setFontSize(16);
    doc.text("KOPI", 165, y);
  }

  y += 10;

  doc.setFontSize(10);
  doc.text(firma.navn || "", 14, y); y += 5;
  doc.text(firma.adresse || "", 14, y); y += 5;

  if (firma.orgnr) {
    doc.text("Org.nr: " + firma.orgnr, 14, y);
    y += 5;
  }

  if (firma.mva_nr || firma.mvanr) {
    doc.text("MVA-nr: " + (firma.mva_nr || firma.mvanr), 14, y);
    y += 5;
  }

  if (firma.epost) {
    doc.text("E-post: " + firma.epost, 14, y);
    y += 5;
  }

  if (firma.kontonr || firma.konto_nr) {
    doc.text("Konto: " + (firma.kontonr || firma.konto_nr), 14, y);
    y += 5;
  }

  y += 5;

  doc.setFontSize(12);
  doc.text("Kunde", 14, y);
  y += 6;

  doc.setFontSize(10);
  doc.text(hentKundeNavn(kunde, fakturaTimer[0]), 14, y);
  y += 5;

  if (kunde.adresse) {
    doc.text(kunde.adresse, 14, y);
    y += 5;
  }

  if (kunde.epost) {
    doc.text("E-post: " + kunde.epost, 14, y);
    y += 5;
  }

  y += 6;

  doc.text("Periode: " + maaned, 14, y); y += 5;
  doc.text("Fakturadato: " + formatDatoISO(fakturaDato), 14, y); y += 5;
  doc.text("Forfall: " + formatDatoISO(forfallsDato), 14, y); y += 8;

  doc.setFontSize(9);
  doc.text("Dato", 14, y);
  doc.text("Beskrivelse", 38, y);
  doc.text("Timer", 112, y);
  doc.text("Sum eks mva", 132, y);
  doc.text("MVA", 162, y);
  doc.text("Inkl mva", 180, y);

  y += 4;
  doc.line(14, y, 200, y);
  y += 5;

  fakturaTimer.forEach(t => {
    if (y > 270) {
      doc.addPage();
      y = 15;
    }

    const linje = beregnMvaLinje(t);
    const tekst = String(t.beskrivelse || t.kommentar || t.kunde_navn || t.kundeNavn || "Timer").slice(0, 38);

    doc.text(String(t.dato || ""), 14, y);
    doc.text(tekst, 38, y);
    doc.text(String(t.timer || 0), 112, y);
    doc.text(formatBelop(linje.sumEksMva), 132, y);
    doc.text(formatBelop(linje.mva), 162, y);
    doc.text(formatBelop(linje.sumInkMva), 180, y);

    y += 6;
  });

  y += 4;
  doc.line(120, y, 200, y);
  y += 7;

  doc.setFontSize(11);
  doc.text("Sum eks mva:", 125, y);
  doc.text(formatBelop(summer.sumEksMva), 180, y);
  y += 6;

  doc.text("MVA 25%:", 125, y);
  doc.text(formatBelop(summer.mva), 180, y);
  y += 6;

  doc.setFontSize(12);
  doc.text("Sum inkl mva:", 125, y);
  doc.text(formatBelop(summer.sumInkMva), 180, y);
  y += 10;

  doc.setFontSize(10);

  if (firma.kontonr || firma.konto_nr) {
    doc.text("Betales til konto: " + (firma.kontonr || firma.konto_nr), 14, y);
    y += 5;
  }

  doc.text("Forfallsdato: " + formatDatoISO(forfallsDato), 14, y);

  const filnavn = `${tryggFilnavn(hentKundeNavn(kunde, fakturaTimer[0]))}_${maaned}${erKopi ? "_KOPI" : ""}.pdf`;
  doc.save(filnavn);
}

async function lagFakturaPdf() {
  const melding = document.getElementById("skjemaMelding");
  const maaned = hentValgtMaaned();
  const firma = await hentFirmaData();
  const valgtKunde = hentValgtKunde();

  const jspdfObj = window.jspdf;

  if (!jspdfObj || !jspdfObj.jsPDF) {
    if (melding) melding.textContent = "PDF-biblioteket er ikke lastet. Sjekk internett og prøv igjen.";
    return;
  }

  const timerForMaaned = (window.timer || [])
    .filter(t => t.fakturerbar !== false)
    .filter(t => String(t.dato || "").slice(0, 7) === maaned)
    .filter(t => erSammeKunde(t, valgtKunde));

  if (!timerForMaaned.length) {
    if (melding) melding.textContent = "Fant ingen fakturerbare timer for valgt kunde og måned.";
    return;
  }

  const grupper = grupperTimerPerKunde(timerForMaaned);

  grupper.forEach(gruppe => {
    const erKopi = hentTimerIGruppeSomIkkeErFakturert(gruppe.timer).length === 0;
    lagEnFakturaPdf(gruppe.kunde, gruppe.timer, maaned, firma, erKopi);
  });

  const mvaCsvLaget = lagMvaCsvForGrupper(grupper, maaned);

  try {
    await markerTimerSomFakturert(grupper);
    await lastTimer();
  } catch (e) {
    if (melding) {
      melding.textContent = "Faktura ble laget, men timer ble ikke markert som fakturert: " + e.message;
    }
    return;
  }

  if (melding) {
    const kundeTekst = valgtKunde
      ? "valgt kunde"
      : `${grupper.length} kunde(r)`;

    melding.textContent = mvaCsvLaget
      ? `Faktura er laget for ${kundeTekst}. MVA-regneark er laget for nye fakturalinjer.`
      : `Fakturakopi er laget for ${kundeTekst}. Ingen nye linjer ble lagt i MVA-regneark.`;
  }
}

function eksporterMvaRegneark() {
  const melding = document.getElementById("skjemaMelding");
  const maaned = hentValgtMaaned();
  const valgtKunde = hentValgtKunde();

  const alleTimer = (window.timer || [])
    .filter(t => t.fakturerbar !== false)
    .filter(t => t.fakturert !== true)
    .filter(t => String(t.dato || "").slice(0, 7) === maaned)
    .filter(t => erSammeKunde(t, valgtKunde));

  if (!alleTimer.length) {
    if (melding) melding.textContent = "Ingen nye, ufakturerte timer å legge i MVA-regneark.";
    return;
  }

  const grupper = grupperTimerPerKunde(alleTimer);
  const laget = lagMvaCsvForGrupper(grupper, maaned);

  if (melding) {
    melding.textContent = laget
      ? "MVA-regneark er laget for ufakturerte timer."
      : "Ingen nye linjer å legge i MVA-regneark.";
  }
}

async function visKreditnotaPrompt() {
  if (typeof erAdmin !== "undefined" && !erAdmin) {
    alert("Bare admin kan lage kreditnota.");
    return;
  }

  if (typeof lagKreditnota !== "function") {
    alert("kreditnota.js er ikke lastet.");
    return;
  }

  const fakturanr = prompt("Skriv fakturanummer som skal krediteres:");

  if (!fakturanr) return;

  await lagKreditnota(fakturanr.trim());
}

window.hentValgtKunde = hentValgtKunde;
window.erSammeKunde = erSammeKunde;
window.beregnMvaLinje = beregnMvaLinje;
window.hentKundeNavn = hentKundeNavn;
window.hentKundeNr = hentKundeNr;
window.hentFirmaData = hentFirmaData;
window.leggTilLogo = leggTilLogo;
window.lagFakturaPdf = lagFakturaPdf;
window.eksporterMvaRegneark = eksporterMvaRegneark;
window.visKreditnotaPrompt = visKreditnotaPrompt;