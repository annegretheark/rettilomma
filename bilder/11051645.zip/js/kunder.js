let kunder = [];

function settKundeMelding(tekst) {
  const el = document.getElementById("kundeMelding");

  if (el) {
    el.textContent = tekst || "";
  }
}

async function lastKunder() {
  const { data, error } =
    await supabaseClient
      .from("kunder")
      .select("*")
      .order("navn", {
        ascending: true
      });

  if (error) {
    console.error(
      "Feil ved henting av kunder:",
      error
    );

    settKundeMelding(
      "Feil ved henting av kunder: " +
      error.message
    );

    return;
  }

  kunder = data || [];

  window.kunder = kunder;

  visKunder();

  fyllKundeDropdown();
}

async function lagreKunde() {
  const id =
    document.getElementById("kundeId")?.value || "";

  const kunde = {
    navn:
      document
        .getElementById("kundeNavn")
        .value
        .trim(),

    adresse:
      document
        .getElementById("kundeAdresse")
        .value
        .trim(),

    epost:
      document
        .getElementById("kundeEpost")
        .value
        .trim(),

    kontaktperson:
      document
        .getElementById("kundeKontaktperson")
        .value
        .trim(),

    kontonr:
      document
        .getElementById("kundeKontonr")
        .value
        .trim()
  };

  if (!kunde.navn) {
    settKundeMelding(
      "Kundenavn må fylles ut."
    );

    return;
  }

  let result;

  if (id) {
    result =
      await supabaseClient
        .from("kunder")
        .update(kunde)
        .eq("id", id)
        .select();
  }
  else {
    result =
      await supabaseClient
        .from("kunder")
        .insert([kunde])
        .select();
  }

  if (result.error) {
    console.error(
      "Feil ved lagring av kunde:",
      result.error
    );

    settKundeMelding(
      "Feil ved lagring av kunde: " +
      result.error.message
    );

    return;
  }

  nullstillKundeSkjema();

  settKundeMelding(
    "Kunde lagret."
  );

  await lastKunder();
}

function visKunder() {
  const liste =
    document.getElementById("kundeListe");

  if (!liste) return;

  liste.innerHTML = "";

  if (!kunder.length) {
    liste.innerHTML =
      "<p>Ingen kunder funnet.</p>";

    return;
  }

  kunder.forEach(kunde => {
    const div =
      document.createElement("div");

    div.className = "card";

    div.innerHTML = `
      <strong>
        ${kunde.navn || ""}
      </strong>
      <br>

      Kundenr:
      ${kunde.kundenr || kunde.kunde_nr || ""}
      <br>

      ${kunde.adresse || ""}
      <br>

      ${kunde.epost || ""}
      <br>

      ${kunde.kontaktperson || ""}
      <br>

      ${kunde.kontonr || ""}
      <br>

      <button
        type="button"
        class="secondary"
        onclick="redigerKunde('${kunde.id}')">

        Rediger

      </button>
    `;

    liste.appendChild(div);
  });
}

function redigerKunde(id) {
  const kunde =
    kunder.find(k =>
      String(k.id) === String(id)
    );

  if (!kunde) {
    alert("Fant ikke kunde");
    return;
  }

  const kundeId =
    document.getElementById("kundeId");

  if (kundeId) {
    kundeId.value = kunde.id;
  }

  document.getElementById(
    "kundeNavn"
  ).value = kunde.navn || "";

  document.getElementById(
    "kundeAdresse"
  ).value = kunde.adresse || "";

  document.getElementById(
    "kundeEpost"
  ).value = kunde.epost || "";

  document.getElementById(
    "kundeKontaktperson"
  ).value =
    kunde.kontaktperson || "";

  document.getElementById(
    "kundeKontonr"
  ).value =
    kunde.kontonr || "";

  settKundeMelding(
    "Redigerer kunde."
  );

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}

function nullstillKundeSkjema() {
  const kundeId =
    document.getElementById("kundeId");

  if (kundeId) {
    kundeId.value = "";
  }

  document.getElementById(
    "kundeNavn"
  ).value = "";

  document.getElementById(
    "kundeAdresse"
  ).value = "";

  document.getElementById(
    "kundeEpost"
  ).value = "";

  document.getElementById(
    "kundeKontaktperson"
  ).value = "";

  document.getElementById(
    "kundeKontonr"
  ).value = "";
}

function hentKundeNr(kunde) {
  return (
    kunde?.kundenr ||
    kunde?.kunde_nr ||
    ""
  );
}

function finnKundeFraValg(verdi) {
  return kunder.find(k =>
    String(k.id || "") === String(verdi) ||
    String(k.kundenr || "") === String(verdi) ||
    String(k.kunde_nr || "") === String(verdi)
  );
}

function fyllKundeDropdown() {
  const valg =
    document.getElementById("kundeValg");

  if (!valg) return;

  valg.innerHTML = "";

  const tomOption =
    document.createElement("option");

  tomOption.value = "";
  tomOption.textContent =
    "Velg kunde";

  tomOption.selected = true;

  valg.appendChild(tomOption);

  kunder.forEach(kunde => {
    const option =
      document.createElement("option");

    const kundeNr =
      hentKundeNr(kunde);

    option.value = kunde.id;

    option.textContent =
      `${kundeNr} - ${kunde.navn || ""}`;

    valg.appendChild(option);
  });

  valg.selectedIndex = 0;
  valg.value = "";

  const kundeNrVisning =
    document.getElementById(
      "kundeNrVisning"
    );

  if (kundeNrVisning) {
    kundeNrVisning.value = "";
  }

  const kundeNavnVisning =
    document.getElementById(
      "kundeNavnVisning"
    );

  if (kundeNavnVisning) {
    kundeNavnVisning.value = "";
  }
}

function visKundeNavn() {
  const verdi =
    document.getElementById(
      "kundeValg"
    ).value;

  const kunde =
    finnKundeFraValg(verdi);

  const nrVisning =
    document.getElementById(
      "kundeNrVisning"
    );

  const navnVisning =
    document.getElementById(
      "kundeNavnVisning"
    );

  const kundeNr =
    hentKundeNr(kunde);

  if (nrVisning) {
    nrVisning.value =
      kunde ? kundeNr : "";
  }

  if (navnVisning) {
    navnVisning.value =
      kunde
        ? (kunde.navn || "")
        : "";
  }
}

window.kunder = kunder;

window.lastKunder = lastKunder;
window.lagreKunde = lagreKunde;
window.redigerKunde = redigerKunde;

window.fyllKundeDropdown =
  fyllKundeDropdown;

window.visKundeNavn =
  visKundeNavn;

window.hentKundeNr =
  hentKundeNr;

window.finnKundeFraValg =
  finnKundeFraValg;

window.tegnKundeListe =
  visKunder;

window.tegnKunder =
  fyllKundeDropdown;