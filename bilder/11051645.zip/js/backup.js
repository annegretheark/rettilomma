function backup() {
  alert("Backup er ikke aktivert i denne versjonen.");
}

function importerBackup() {
  alert("Import er ikke aktivert i denne versjonen.");
}

window.backup = backup;
window.importerBackup = importerBackup;
