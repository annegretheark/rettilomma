console.log("lonn.js er lastet");

let sisteLonnData = [];
let sisteFirma = {};

function lonnMelding(tekst, erFeil = false) {
  const el = document.getElementById("lonnMelding");

  if (el) {
    el.textContent = tekst || "";
    el.style.color = erFeil ? "#b42318" : "#116329";
  }
}

function lonnTall(verdi) {
  if (verdi === null || verdi === undefined || verdi === "") return 0;

  const n = Number(String(verdi).replace(",", "."));

  return Number.isFinite(n) ? n : 0;
}

function lonnRund(n) {
  return Math.round((lonnTall(n) + Number.EPSILON) * 100) / 100;
}

function kroner(n) {
  return lonnRund(n).toLocaleString("no-NO", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function finnTimerAntall(rad) {
  if (rad.timer !== undefined && rad.timer !== null) {
    return lonnTall(rad.timer);
  }

  return 0;
}

function hentAnsattNavn(ansatt, ansattId) {
  return (
    ansatt?.navn ||
    ansatt?.name ||
    ansatt?.epost ||
    ansatt?.email ||
    ansattId ||
    "Ukjent ansatt"
  );
}

function hentTimelonn(ansatt, timerad) {
  return lonnTall(
    ansatt?.timelonn ||
    ansatt?.time_lonn ||
    timerad?.timepris ||
    0
  );
}

function beregnSkatt(brutto, ansatt) {
  const skattVerdi = lonnTall(
    ansatt?.skattetrekk ||
    ansatt?.skatt ||
    ansatt?.skatteprosent
  );

  if (skattVerdi <= 0) return 0;

  if (skattVerdi <= 100) {
    return lonnRund(brutto * skattVerdi / 100);
  }

  return lonnRund(skattVerdi);
}

function hentAndreTrekk(ansatt) {
  const detaljer = {};
  let sum = 0;

  const pensjon = lonnTall(
    ansatt?.pensjon ||
    ansatt?.pensjonstrekk
  );

  if (pensjon) {
    detaljer.Pensjon = pensjon;
    sum += pensjon;
  }

  const fagforening = lonnTall(
    ansatt?.fagforening ||
    ansatt?.fagforeningstrekk
  );

  if (fagforening) {
    detaljer.Fagforening = fagforening;
    sum += fagforening;
  }

  const andre = lonnTall(
    ansatt?.andre_trekk ||
    ansatt?.trekk
  );

  if (andre) {
    detaljer["Andre trekk"] = andre;
    sum += andre;
  }

  return {
    sum: lonnRund(sum),
    detaljer
  };
}

async function hentOgBeregnLonn() {
  if (typeof supabaseClient === "undefined") {
    throw new Error("Supabase er ikke lastet.");
  }

  const [timerRes, ansatteRes, firmaRes] = await Promise.all([
    supabaseClient.from("timer").select("*"),
    supabaseClient.from("ansatte").select("*"),
    supabaseClient.from("firma").select("*").limit(1).maybeSingle()
  ]);

  if (timerRes.error) {
    throw new Error("Feil ved henting av timer: " + timerRes.error.message);
  }

  if (ansatteRes.error) {
    throw new Error("Feil ved henting av ansatte: " + ansatteRes.error.message);
  }

  if (firmaRes.error) {
    console.warn("Kunne ikke hente firma:", firmaRes.error);
  }

  const timerader = timerRes.data || [];
  const ansatte = ansatteRes.data || [];

  sisteFirma = firmaRes.data || {};

  const ansatteMap = new Map(
    ansatte.map(a => [String(a.id), a])
  );

  const grupper = new Map();

  timerader.forEach(t => {
    const ansattId = String(t.ansatt_id || "");

    if (!ansattId) return;

    const ansatt = ansatteMap.get(ansattId) || {};
    const key = ansattId;

    if (!grupper.has(key)) {
      grupper.set(key, {
        ansattId,
        ansatt,
        ansattNavn: hentAnsattNavn(ansatt, ansattId),
        epost: ansatt.epost || "",
        kontonr: ansatt.kontonr || ansatt.konto_nr || "",
        timer: 0,
        overtid50: 0,
        overtid100: 0,
        brutto: 0,
        skatt: 0,
        ekstraSkatt: lonnTall(ansatt.ekstra_skatt || ansatt.ekstraskatt),
        andreTrekk: 0,
        trekkDetaljer: {},
        feriepengerGrunnlag: 0,
        netto: 0,
        periodeFra: "",
        periodeTil: ""
      });
    }

    const g = grupper.get(key);

    const totalTimer = finnTimerAntall(t);
    const ot50 = lonnTall(t.overtid50 || t.overtid_50);
    const ot100 = lonnTall(t.overtid100 || t.overtid_100);
    const normalTimer = Math.max(totalTimer - ot50 - ot100, 0);
    const timelonn = hentTimelonn(ansatt, t);

    let bruttoRad = 0;

    if (timelonn > 0) {
      bruttoRad =
        normalTimer * timelonn +
        ot50 * timelonn * 1.5 +
        ot100 * timelonn * 2;
    } else {
      bruttoRad = lonnTall(t.sum_timer || t.sum || 0);
    }

    g.timer += totalTimer;
    g.overtid50 += ot50;
    g.overtid100 += ot100;
    g.brutto += bruttoRad;

    const dato = String(t.dato || "");

    if (dato) {
      if (!g.periodeFra || dato < g.periodeFra) g.periodeFra = dato;
      if (!g.periodeTil || dato > g.periodeTil) g.periodeTil = dato;
    }
  });

  const resultat = Array.from(grupper.values()).map(g => {
    const andre = hentAndreTrekk(g.ansatt);

    g.timer = lonnRund(g.timer);
    g.overtid50 = lonnRund(g.overtid50);
    g.overtid100 = lonnRund(g.overtid100);
    g.brutto = lonnRund(g.brutto);
    g.skatt = beregnSkatt(g.brutto, g.ansatt);
    g.ekstraSkatt = lonnRund(g.ekstraSkatt);
    g.andreTrekk = andre.sum;
    g.trekkDetaljer = andre.detaljer;
    g.feriepengerGrunnlag = g.brutto;
    g.netto = lonnRund(
      g.brutto -
      g.skatt -
      g.ekstraSkatt -
      g.andreTrekk
    );

    return g;
  }).sort((a, b) => a.ansattNavn.localeCompare(b.ansattNavn, "no"));

  sisteLonnData = resultat;

  return resultat;
}

async function kjorLonn() {
  try {
    lonnMelding("Henter timer og beregner lønn...");

    const data = await hentOgBeregnLonn();

    if (!data.length) {
      lonnMelding("Ingen timer funnet å beregne lønn fra.", true);
      return;
    }

    const sumNetto = data.reduce((s, r) => s + r.netto, 0);

    lonnMelding(
      `Lønn beregnet for ${data.length} ansatt(e). Netto utbetales: ${kroner(sumNetto)} kr`
    );

  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
  }
}

async function eksporterTrekkExcel() {
  try {
    const data = sisteLonnData.length
      ? sisteLonnData
      : await hentOgBeregnLonn();

    const rader = [];

    data.forEach(r => {
      rader.push({
        Periode: `${r.periodeFra || ""} - ${r.periodeTil || ""}`,
        Ansattnr: r.ansatt?.ansatt_nr || r.ansatt?.ansattnr || "",
        Ansatt: r.ansattNavn,
        Bruttolonn: r.brutto,
        Forskuddstrekk: r.skatt,
        EkstraSkatt: r.ekstraSkatt,
        Pensjon: r.trekkDetaljer.Pensjon || 0,
        Fagforening: r.trekkDetaljer.Fagforening || 0,
        AndreTrekk: r.trekkDetaljer["Andre trekk"] || 0,
        SumTrekk: lonnRund(r.skatt + r.ekstraSkatt + r.andreTrekk),
        NettoUtbetalt: r.netto,
        Feriepengegrunnlag: r.feriepengerGrunnlag
      });
    });

    lagRegneark("skattetrekk_og_trekk.xlsx", "Trekk", rader);

    lonnMelding("Excel med skattetrekk og trekk er laget.");

  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
  }
}

async function eksporterUtbetalingerExcel() {
  try {
    const data = sisteLonnData.length
      ? sisteLonnData
      : await hentOgBeregnLonn();

    const rader = [];

    data.forEach(r => {
      rader.push({
        Type: "Netto lønn",
        Mottaker: r.ansattNavn,
        Kontonr: r.kontonr,
        Belop: r.netto
      });

      if (r.skatt || r.ekstraSkatt) {
        rader.push({
          Type: "Skatt",
          Mottaker: "Skatteetaten",
          Kontonr: "",
          Belop: lonnRund(r.skatt + r.ekstraSkatt)
        });
      }

      if (r.trekkDetaljer.Pensjon) {
        rader.push({
          Type: "Pensjon",
          Mottaker: "Pensjon",
          Kontonr: "",
          Belop: r.trekkDetaljer.Pensjon
        });
      }

      if (r.trekkDetaljer.Fagforening) {
        rader.push({
          Type: "Fagforening",
          Mottaker: "Fagforening",
          Kontonr: "",
          Belop: r.trekkDetaljer.Fagforening
        });
      }

      if (r.trekkDetaljer["Andre trekk"]) {
        rader.push({
          Type: "Andre trekk",
          Mottaker: "Andre trekk",
          Kontonr: "",
          Belop: r.trekkDetaljer["Andre trekk"]
        });
      }
    });

    lagRegneark("utbetalinger.xlsx", "Utbetalinger", rader);

    lonnMelding("Utbetalinger Excel er laget.");

  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
  }
}

async function lagLonnsslipper(kopi = false) {
  try {
    const data = sisteLonnData.length
      ? sisteLonnData
      : await hentOgBeregnLonn();

    if (!data.length) {
      lonnMelding("Ingen lønnsslipper å lage.", true);
      return;
    }

    if (!window.jspdf || !window.jspdf.jsPDF) {
      alert("PDF-biblioteket er ikke lastet.");
      return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    const idag = new Date();

    const maaned = idag.toLocaleString("no-NO", {
      month: "long"
    });

    const aar = idag.getFullYear();
    const utbetalingsDato = idag.toLocaleDateString("no-NO");

    data.forEach((r, index) => {
      if (index > 0) doc.addPage();

      let y = 20;

      doc.setFontSize(16);
      doc.text(kopi ? "LØNNSAVREGNING - KOPI" : "LØNNSAVREGNING", 20, y);

      y += 12;

      doc.setFontSize(10);

      doc.text("Ansattnr: " + (r.ansatt?.ansatt_nr || r.ansatt?.ansattnr || ""), 20, y);
      y += 6;

      doc.text("Navn: " + r.ansattNavn, 20, y);
      y += 6;

      doc.text("Adresse: " + (r.ansatt?.adresse || ""), 20, y);
      y += 6;

      doc.text("Postadresse: " + (r.ansatt?.postadresse || ""), 20, y);
      y += 10;

      doc.text(`Lønnsavregning for ${maaned} ${aar}`, 20, y);
      y += 6;

      doc.text("Utbetalingsdato: " + utbetalingsDato, 20, y);
      y += 12;

      doc.text("Tabell/%", 20, y);
      doc.text(String(r.ansatt?.skattetrekk || r.ansatt?.skatteprosent || ""), 50, y);
      doc.text("Kontonr", 80, y);
      doc.text(r.kontonr || "", 110, y);
      y += 6;

      doc.text("Stillings%", 20, y);
      doc.text(String(r.ansatt?.stillingsprosent || "100"), 50, y);
      doc.text("Kostnadssted", 80, y);
      doc.text(String(r.ansatt?.kostnadssted || ""), 120, y);
      y += 6;

      doc.text("Feriepenger opptjent", 20, y);
      doc.text(kroner(r.feriepengerGrunnlag) + " kr", 80, y);
      y += 12;

      doc.setFontSize(11);

      doc.text("Type", 20, y);
      doc.text("Antall", 80, y);
      doc.text("Beløp", 130, y);

      y += 6;
      doc.line(20, y, 190, y);
      y += 8;

      doc.text("Timer", 20, y);
      doc.text(String(r.timer), 80, y);
      doc.text(kroner(r.brutto) + " kr", 130, y);
      y += 8;

      doc.text("Overtid 50%", 20, y);
      doc.text(String(r.overtid50), 80, y);
      doc.text("", 130, y);
      y += 8;

      doc.text("Overtid 100%", 20, y);
      doc.text(String(r.overtid100), 80, y);
      doc.text("", 130, y);
      y += 8;

      doc.text("Forskuddstrekk", 20, y);
      doc.text("", 80, y);
      doc.text("- " + kroner(r.skatt) + " kr", 130, y);
      y += 8;

      doc.text("Ekstra skatt", 20, y);
      doc.text("", 80, y);
      doc.text("- " + kroner(r.ekstraSkatt) + " kr", 130, y);
      y += 8;

      doc.text("Andre trekk", 20, y);
      doc.text("", 80, y);
      doc.text("- " + kroner(r.andreTrekk) + " kr", 130, y);
      y += 12;

      doc.line(20, y, 190, y);
      y += 10;

      doc.setFontSize(12);

      doc.text("Brutto lønn", 20, y);
      doc.text(kroner(r.brutto) + " kr", 130, y);
      y += 8;

      doc.text("Forskuddstrekk", 20, y);
      doc.text("- " + kroner(r.skatt) + " kr", 130, y);
      y += 8;

      doc.text("Netto utbetalt", 20, y);
      doc.text(kroner(r.netto) + " kr", 130, y);
    });

    doc.save(kopi ? "lonnsslipper_kopi.pdf" : "lonnsslipper.pdf");

    lonnMelding("Lønnsslipper er laget.");

  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
  }
}

function lagRegneark(filnavn, arkNavn, rader) {
  if (!rader || !rader.length) {
    alert("Ingen data å eksportere.");
    return;
  }

  if (window.XLSX) {
    const ws = XLSX.utils.json_to_sheet(rader);
    const wb = XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(wb, ws, arkNavn);
    XLSX.writeFile(wb, filnavn);

    return;
  }

  const overskrifter = Object.keys(rader[0]);

  const csv = [
    overskrifter.join(";"),
    ...rader.map(rad =>
      overskrifter
        .map(k => String(rad[k] ?? "").replaceAll(";", ","))
        .join(";")
    )
  ].join("\n");

  const blob = new Blob(["\ufeff" + csv], {
    type: "text/csv;charset=utf-8;"
  });

  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filnavn.replace(".xlsx", ".csv");

  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

window.kjorLonn = kjorLonn;
window.lagLonnsslipper = lagLonnsslipper;
window.eksporterTrekkExcel = eksporterTrekkExcel;
window.eksporterUtbetalingerExcel = eksporterUtbetalingerExcel;
window.hentOgBeregnLonn = hentOgBeregnLonn;