console.log("beh-fakturaoversikt.js lastet - kompakt og klikkbar");

let sisteBehFakturaOversikt = [];
let behFakturaFilter = "alle";
let behFakturaSok = "";
let behFakturaValgt = null;

function oversiktKr(n) {
  return Number(n || 0).toLocaleString("no-NO", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}


function hentVippsTekstFraFirma(firma) {
  firma = firma || {};
  const nummer = firma.vipps_nummer || firma.vippsnummer || firma.vipps_nr || firma.vipps || firma.vipps_bedrift || "";
  const mottaker = firma.vipps_mottaker || firma.vipps_navn || firma.vippsNavn || firma.navn || firma.firmanavn || "";
  return {
    nummer: String(nummer || "").trim(),
    mottaker: String(mottaker || "").trim()
  };
}

async function hentBehFirmaTilPdf() {
  let firma = {};

  try {
    if (typeof hentFirmaData === "function") {
      const hentet = await hentFirmaData();
      if (hentet && typeof hentet === "object") firma = hentet;
    }
  } catch (e) {
    console.warn("Kunne ikke hente firma via hentFirmaData:", e);
  }

  if ((!firma || !Object.keys(firma).length || (!hentVippsTekstFraFirma(firma).nummer && !hentVippsTekstFraFirma(firma).mottaker)) && window.supabaseClient) {
    const tabeller = ["beh_firma", "beh_firma"];
    for (const tabell of tabeller) {
      try {
        const { data, error } = await supabaseClient
          .from(tabell)
          .select("*")
          .limit(1)
          .maybeSingle();
        if (!error && data) {
          firma = { ...firma, ...data };
          break;
        }
      } catch (e) {
        console.warn("Kunne ikke hente firma fra", tabell, e);
      }
    }
  }

  return firma || {};
}

function tegnVippsPdf(doc, firma, x, y) {
  const vipps = hentVippsTekstFraFirma(firma);
  if (!vipps.nummer && !vipps.mottaker) return y;

  if (y > 250) {
    doc.addPage();
    y = 25;
  }

  doc.setFontSize(11);
  doc.text("Betaling med Vipps", x, y);
  y += 7;
  doc.setFontSize(10);

  if (vipps.nummer) {
    doc.text("Vipps: " + vipps.nummer, x, y);
    y += 6;
  }

  if (vipps.mottaker) {
    doc.text("Mottaker: " + vipps.mottaker, x, y);
    y += 6;
  }

  return y;
}

function safeText(v) {
  return String(v ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function normaliserStatus(f) {
  if (f.kreditert) return "kreditert";
  const status = String(f.betalingsstatus || "ubetalt").toLowerCase();
  if (status === "purring" || status === "purret") return "purret";
  if (status === "betalt") return "betalt";
  if (status === "kreditert") return "kreditert";
  return "ubetalt";
}

function beregnUtestaende(f) {
  const inkl = Number(f.inkl_mva || 0);
  const betalt = Number(f.betalt_belop || 0);
  const status = normaliserStatus(f);

  if (status === "betalt" || status === "kreditert") return 0;
  return Math.max(inkl - betalt, 0);
}

function behDatoNo(v) {
  if (!v) return "";
  const s = String(v).slice(0, 10);
  const d = s.split("-");
  return d.length === 3 ? `${d[2]}.${d[1]}.${d[0]}` : String(v);
}

function hentFiltrerteFakturaer() {
  let rader = [...sisteBehFakturaOversikt];

  // Sikring mot dobbel visning hvis samme fakturanr skulle komme flere ganger fra databasen.
  const unike = new Map();
  for (const f of rader) {
    const key = String(f.fakturanr || f.id || "");
    if (key && !unike.has(key)) unike.set(key, f);
  }
  rader = [...unike.values()];

  if (behFakturaFilter !== "alle") {
    rader = rader.filter(f => normaliserStatus(f) === behFakturaFilter);
  }

  const sok = behFakturaSok.trim().toLowerCase();
  if (sok) {
    rader = rader.filter(f => {
      const kunde = (f.kunder?.navn || f.kunde_navn || "").toLowerCase();
      const fakturanr = String(f.fakturanr || "").toLowerCase();
      const dato = String(f.dato || "").toLowerCase();
      const status = normaliserStatus(f).toLowerCase();

      return kunde.includes(sok) || fakturanr.includes(sok) || dato.includes(sok) || status.includes(sok);
    });
  }

  return rader;
}

function statusTekst(status) {
  if (status === "betalt") return "Betalt";
  if (status === "kreditert") return "Kreditert";
  if (status === "purret") return "Purret";
  return "Ubetalt";
}

function fakturertTekst(f) {
  return f.fakturanr ? "Fakturert" : "Ikke fakturert";
}


function statusKnappHtml(f) {
  const status = normaliserStatus(f);
  const tekst = statusTekst(status);
  const fakturanr = safeText(f.fakturanr || "");
  const belop = Number(f.inkl_mva || 0);

  if (status === "betalt") return `<span title="Betalt">✓ Betalt</span>`;
  if (status === "kreditert") return `<span title="Kreditert">Kreditert</span>`;

  return `<button type="button" class="secondary" title="Klikk for å markere som betalt" style="padding:4px 7px;font-size:11px;white-space:nowrap;" onclick="event.stopPropagation(); markerBehFakturaBetalt('${fakturanr}', ${belop})">${safeText(tekst)}</button>`;
}

function purringKnappHtml(f, liten = false) {
  const status = normaliserStatus(f);
  if (status === "betalt" || status === "kreditert") return "";
  const tekst = status === "purret" ? "Ny purring" : "Purring";
  const cls = liten ? ' class="secondary" style="padding:4px 7px;font-size:11px;white-space:nowrap;"' : "";
  return `<button type="button"${cls} onclick="event.stopPropagation(); lagBehPurring('${safeText(f.fakturanr)}')">${tekst}</button>`;
}

function sikreFakturaDetalj() {
  let detalj = document.getElementById("behFakturaDetalj");
  const oversikt = document.getElementById("fakturaOversikt");

  if (!detalj) {
    detalj = document.createElement("div");
    detalj.id = "behFakturaDetalj";
    detalj.className = "listekort";
    detalj.style.display = "none";
    detalj.style.marginBottom = "12px";
    oversikt?.parentNode?.insertBefore(detalj, oversikt);
  }

  return detalj;
}

function visBehFakturaDetalj(fakturanr) {
  const f = sisteBehFakturaOversikt.find(x => String(x.fakturanr) === String(fakturanr));
  if (!f) return;

  behFakturaValgt = f;
  const detalj = sikreFakturaDetalj();
  const status = normaliserStatus(f);
  const kunde = f.kunder?.navn || f.kunde_navn || "";
  const inkl = Number(f.inkl_mva || 0);
  const betalt = Number(f.betalt_belop || 0);
  const utestaende = beregnUtestaende(f);

  const betalKnapp = status === "betalt" || status === "kreditert"
    ? ""
    : `<button type="button" onclick="event.stopPropagation(); markerBehFakturaBetalt('${safeText(f.fakturanr)}', ${inkl})">Marker betalt</button>`;

  detalj.style.display = "block";
  detalj.innerHTML = `
    <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap;">
      <h3 style="margin:0;">Faktura ${safeText(f.fakturanr || "")}</h3>
      <button type="button" class="secondary" onclick="lukkBehFakturaDetalj()">Lukk</button>
    </div>

    <div class="rad" style="margin-top:12px;">
      <div><strong>Kunde:</strong><br>${safeText(kunde)}</div>
      <div><strong>Dato:</strong><br>${safeText(behDatoNo(f.dato || ""))}</div>
      <div><strong>Status:</strong><br>${safeText(statusTekst(status))}</div>
      <div><strong>Eks. mva:</strong><br>${oversiktKr(f.eks_mva)} kr</div>
      <div><strong>MVA:</strong><br>${oversiktKr(f.mva)} kr</div>
      <div><strong>Inkl. mva:</strong><br><b>${oversiktKr(inkl)} kr</b></div>
      <div><strong>Betalt:</strong><br>${oversiktKr(betalt)} kr</div>
      <div><strong>Utestående:</strong><br>${oversiktKr(utestaende)} kr</div>
      <div><strong>Betalt dato:</strong><br>${safeText(behDatoNo(f.betalt_dato || ""))}</div>
    </div>

    <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
      ${purringKnappHtml(f)}
      ${betalKnapp}
    </div>
  `;

  detalj.scrollIntoView({ behavior: "smooth", block: "start" });
}

function lukkBehFakturaDetalj() {
  const detalj = document.getElementById("behFakturaDetalj");
  if (detalj) {
    detalj.style.display = "none";
    detalj.innerHTML = "";
  }
  behFakturaValgt = null;
}

function tegnFakturaOversikt() {
  const div = document.getElementById("fakturaOversikt");
  if (!div) return;

  sikreFakturaDetalj();

  const rader = hentFiltrerteFakturaer();
  const sumInkl = rader.reduce((s, f) => s + Number(f.inkl_mva || 0), 0);
  const sumBetalt = rader.reduce((s, f) => s + Number(f.betalt_belop || 0), 0);
  const sumUtestaende = rader.reduce((s, f) => s + beregnUtestaende(f), 0);

  const filterKnapp = (verdi, tekst) => `
    <button type="button" onclick="settBehFakturaFilter('${verdi}')" class="${behFakturaFilter === verdi ? "" : "secondary"}">
      ${tekst}
    </button>
  `;

  const tabellRader = rader.map(f => {
    const status = normaliserStatus(f);
    const kunde = f.kunder?.navn || f.kunde_navn || "";
    const fakturanr = safeText(f.fakturanr || "");

    return `
      <tr onclick="visBehFakturaDetalj('${fakturanr}')" style="cursor:pointer;">
        <td style="padding:6px;border-bottom:1px solid #374151;white-space:nowrap;max-width:115px;overflow:hidden;text-overflow:ellipsis;">${fakturanr}</td>
        <td style="padding:6px;border-bottom:1px solid #374151;white-space:nowrap;">${safeText(behDatoNo(f.dato || ""))}</td>
        <td style="padding:6px;border-bottom:1px solid #374151;max-width:135px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${safeText(kunde)}</td>
        <td style="padding:6px;border-bottom:1px solid #374151;text-align:right;white-space:nowrap;"><b>${oversiktKr(f.inkl_mva)}</b></td>
        <td style="padding:6px;border-bottom:1px solid #374151;white-space:nowrap;">${safeText(fakturertTekst(f))}</td>
        <td style="padding:5px;border-bottom:1px solid #374151;white-space:nowrap;">${statusKnappHtml(f)}</td>
        <td style="padding:5px;border-bottom:1px solid #374151;white-space:nowrap;text-align:right;">${purringKnappHtml(f, true)}</td>
      </tr>
    `;
  }).join("");

  div.innerHTML = `
    <div class="listekort" style="max-width:100%;overflow:hidden;">
      <div class="rad">
        <div>
          <label for="fakturaOversiktSok">Søk</label>
          <input id="fakturaOversiktSok" placeholder="Søk kunde, fakturanr, dato eller status" value="${safeText(behFakturaSok)}" oninput="settBehFakturaSok(this.value)">
        </div>
      </div>

      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
        ${filterKnapp("alle", "Alle")}
        ${filterKnapp("ubetalt", "Ubetalt")}
        ${filterKnapp("purret", "Purret")}
        ${filterKnapp("betalt", "Betalt")}
        ${filterKnapp("kreditert", "Kreditert")}
      </div>

      <div style="overflow-x:auto; margin-top:12px; max-width:100%;">
        <table style="width:100%; border-collapse:collapse; min-width:680px; font-size:11px; line-height:1.2; table-layout:fixed;">
          <thead>
            <tr>
              <th style="text-align:left;border-bottom:1px solid #475569;padding:5px;width:98px;">Fakturanr</th>
              <th style="text-align:left;border-bottom:1px solid #475569;padding:5px;width:78px;">Dato</th>
              <th style="text-align:left;border-bottom:1px solid #475569;padding:5px;">Kunde</th>
              <th style="text-align:right;border-bottom:1px solid #475569;padding:5px;width:92px;">Beløp</th>
              <th style="text-align:left;border-bottom:1px solid #475569;padding:5px;width:78px;">Fakt.</th>
              <th style="text-align:left;border-bottom:1px solid #475569;padding:5px;width:76px;">Status</th>
              <th style="text-align:right;border-bottom:1px solid #475569;padding:5px;width:82px;">Purring</th>
            </tr>
          </thead>
          <tbody>
            ${tabellRader || `<tr><td colspan="7" style="padding:12px;">Ingen fakturaer å vise.</td></tr>`}
          </tbody>
        </table>
      </div>

      <div style="margin-top:14px; line-height:1.7;">
        <b>Antall:</b> ${rader.length}<br>
        <b>Sum inkl. mva:</b> ${oversiktKr(sumInkl)} kr<br>
        <b>Betalt:</b> ${oversiktKr(sumBetalt)} kr<br>
        <b>Utestående:</b> ${oversiktKr(sumUtestaende)} kr<br>
        <small>Klikk på en faktura for detaljer.</small>
      </div>
    </div>
  `;
}

async function hentFakturaOversikt() {
  const res = await supabaseClient
    .from("beh_fakturaer")
    .select("*, kunder:beh_kunder(navn)")
    .order("dato", { ascending: false })
    .order("fakturanr", { ascending: false });

  if (res.error) {
    alert(res.error.message);
    return;
  }

  sisteBehFakturaOversikt = res.data || [];
  tegnFakturaOversikt();
}

function settBehFakturaFilter(filter) {
  behFakturaFilter = filter || "alle";
  tegnFakturaOversikt();
}

function settBehFakturaSok(verdi) {
  behFakturaSok = verdi || "";
  tegnFakturaOversikt();

  const input = document.getElementById("fakturaOversiktSok");
  if (input) {
    input.focus();
    const len = input.value.length;
    input.setSelectionRange(len, len);
  }
}

async function markerBehFakturaBetalt(fakturanr, belop) {
  const res = await supabaseClient
    .from("beh_fakturaer")
    .update({
      betalingsstatus: "betalt",
      betalt_belop: belop,
      betalt_dato: new Date().toISOString().slice(0, 10)
    })
    .eq("fakturanr", fakturanr);

  if (res.error) {
    alert(res.error.message);
    return;
  }

  await hentFakturaOversikt();
  visBehFakturaDetalj(fakturanr);
}

async function lagBehPurring(fakturanr) {
  const f = sisteBehFakturaOversikt.find(x => String(x.fakturanr) === String(fakturanr));
  if (!f) {
    alert("Fant ikke fakturaen.");
    return;
  }

  const status = normaliserStatus(f);
  if (status === "betalt" || status === "kreditert") {
    alert("Denne fakturaen er allerede avsluttet.");
    return;
  }

  try {
    const { jsPDF } = window.jspdf || {};
    if (!jsPDF) {
      alert("PDF-biblioteket mangler.");
      return;
    }

    const firma = await hentBehFirmaTilPdf();
    const kunde = f.kunder?.navn || f.kunde_navn || "";
    const inkl = Number(f.inkl_mva || 0);
    const betalt = Number(f.betalt_belop || 0);
    const utestaende = beregnUtestaende(f);
    const iDag = new Date().toISOString().slice(0, 10);

    const doc = new jsPDF();
    if (typeof tegnBrevhodePdf === "function") {
      await tegnBrevhodePdf(doc, firma);
    }

    let y = 56;
    doc.setFontSize(18);
    doc.text("PURRING", 20, y);
    y += 10;
    doc.setFontSize(10);
    doc.text("Fakturanr: " + String(f.fakturanr || ""), 20, y);
    y += 7;
    doc.text("Purringsdato: " + iDag, 20, y);
    y += 7;
    doc.text("Opprinnelig fakturadato: " + String(f.dato || ""), 20, y);
    y += 14;

    doc.setFontSize(12);
    doc.text("Kunde:", 20, y);
    y += 7;
    doc.setFontSize(10);
    doc.text(String(kunde || ""), 20, y);
    y += 16;

    doc.setFontSize(11);
    doc.text("Dette er en purring på ubetalt faktura.", 20, y);
    y += 12;
    doc.text("Fakturasum:", 20, y);
    doc.text(oversiktKr(inkl) + " kr", 130, y);
    y += 7;
    doc.text("Registrert betalt:", 20, y);
    doc.text(oversiktKr(betalt) + " kr", 130, y);
    y += 9;
    doc.setFontSize(13);
    doc.text("Utestående:", 20, y);
    doc.text(oversiktKr(utestaende) + " kr", 130, y);

    y += 16;
    y = tegnVippsPdf(doc, firma, 20, y);

    if (typeof tegnBrevfotAlleSiderPdf === "function") {
      tegnBrevfotAlleSiderPdf(doc, firma);
    }

    const oppdaterRes = await supabaseClient
      .from("beh_fakturaer")
      .update({ betalingsstatus: "purret" })
      .eq("fakturanr", fakturanr);

    if (oppdaterRes.error) {
      alert("Purring-PDF ble laget, men status ble ikke lagret: " + oppdaterRes.error.message);
    }

    doc.save("Purring-" + String(fakturanr || "faktura") + ".pdf");
    await hentFakturaOversikt();
    visBehFakturaDetalj(fakturanr);
  } catch (e) {
    console.error("Feil ved purring:", e);
    alert("Kunne ikke lage purring: " + (e.message || e));
  }
}

async function eksporterFakturaOversiktExcel() {
  if (!window.XLSX) {
    alert("Excel-biblioteket mangler");
    return;
  }

  if (!sisteBehFakturaOversikt.length) await hentFakturaOversikt();

  const rader = hentFiltrerteFakturaer().map(f => ({
    Fakturanr: f.fakturanr,
    Kunde: f.kunder?.navn || f.kunde_navn || "",
    Dato: f.dato,
    "Eks mva": Number(f.eks_mva || 0),
    MVA: Number(f.mva || 0),
    "Inkl mva": Number(f.inkl_mva || 0),
    Fakturert: fakturertTekst(f),
    Status: normaliserStatus(f),
    "Betalt beløp": Number(f.betalt_belop || 0),
    "Betalt dato": f.betalt_dato || "",
    "Utestående": beregnUtestaende(f)
  }));

  const ws = XLSX.utils.json_to_sheet(rader);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Fakturaoversikt");
  XLSX.writeFile(wb, "hestebehandler_fakturaoversikt.xlsx");
}

window.hentFakturaOversikt = hentFakturaOversikt;
window.eksporterFakturaOversiktExcel = eksporterFakturaOversiktExcel;
window.markerBehFakturaBetalt = markerBehFakturaBetalt;
window.lagBehPurring = lagBehPurring;
window.settBehFakturaFilter = settBehFakturaFilter;
window.settBehFakturaSok = settBehFakturaSok;
window.visBehFakturaDetalj = visBehFakturaDetalj;
window.lukkBehFakturaDetalj = lukkBehFakturaDetalj;
