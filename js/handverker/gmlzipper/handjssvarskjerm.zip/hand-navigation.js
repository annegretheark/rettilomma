/* Rett i Lomma - CLEAN NAV 20260626
   Ett sted styrer toppmeny/adminmeny. Admin-sider vises bare når valgt.
*/
(function () {
  'use strict';

  var SIDE_IDS = [
    'timerSide','jobberSide','fravaerSide','bilerSide',
    'kundeSide','kunderSide','tilbudSide','fakturaSide','varerSide',
    'bilBestillingerSide','adminBilBestillinger','adminBilBestillingerPanel',
    'lonnPanel','lonnSide','ansattSide','ansatteSide','firmaSide',
    'backupSide','testSide','testpanelSide','modulerSide','sysadminPanelSide','adminSide','adminKonsollSide'
  ];

  function $(id) { return document.getElementById(id); }
  function val(v) { return String(v == null ? '' : v).trim(); }
  function low(v) { return val(v).toLowerCase(); }

  function currentRole() {
    return low(window.innloggetRolle || window.handInnloggetRolle || localStorage.getItem('handInnloggetRolle') || localStorage.getItem('innloggetRolle'));
  }
  function currentEmail() {
    return low(window.innloggetEpost || window.handInnloggetEpost || window.innloggetBrukerEpost || localStorage.getItem('handInnloggetEpost') || localStorage.getItem('innloggetEpost'));
  }
  function isAdmin() {
    var r = currentRole();
    return window.erAdmin === true || r === 'admin' || r === 'sysadm' || r === 'sysadmin' || localStorage.getItem('rilAdminModus') === 'ja';
  }
  function isSysadmin() {
    var r = currentRole();
    var e = currentEmail();
    return window.erSystemadmin === true || r === 'sysadm' || r === 'sysadmin' || r === 'systemadmin' || e === 'greknuts@online.no';
  }

  function show(el) {
    if (!el) return;
    el.hidden = false;
    el.classList.remove('hidden','skjult','modul-skjult','ril-starter');
    el.style.setProperty('display', 'block', 'important');
    el.style.removeProperty('visibility');
    el.removeAttribute('aria-hidden');
  }
  function showInline(el) {
    if (!el) return;
    el.hidden = false;
    el.classList.remove('hidden','skjult','modul-skjult');
    el.style.removeProperty('display');
    el.style.removeProperty('visibility');
    el.removeAttribute('aria-hidden');
  }
  function hide(el) {
    if (!el) return;
    el.hidden = true;
    el.classList.add('hidden','skjult');
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('aria-hidden', 'true');
  }

  function closeAdminMenu() {
    var group = $('adminMenyGruppe');
    var panel = $('adminMenyPanel');
    var btn = $('adminMenyKnapp');
    if (group) group.classList.remove('apen','open');
    if (panel) {
      panel.hidden = true;
      panel.classList.remove('apen','open');
      panel.style.setProperty('display','none','important');
      panel.style.setProperty('visibility','hidden','important');
      panel.style.setProperty('pointer-events','none','important');
      panel.setAttribute('aria-hidden','true');
    }
    if (btn) btn.setAttribute('aria-expanded','false');
  }

  function toggleAdminMenu() {
    if (!isAdmin()) return false;
    var group = $('adminMenyGruppe');
    var panel = $('adminMenyPanel');
    var btn = $('adminMenyKnapp');
    if (!panel) return false;
    var open = !(panel.hidden || panel.style.display === 'none');
    if (open) { closeAdminMenu(); return false; }
    if (group) group.classList.add('apen','open');
    panel.hidden = false;
    panel.classList.add('apen','open');
    panel.style.setProperty('display','block','important');
    panel.style.setProperty('visibility','visible','important');
    panel.style.setProperty('pointer-events','auto','important');
    panel.setAttribute('aria-hidden','false');
    if (btn) btn.setAttribute('aria-expanded','true');
    return false;
  }

  function setTitle(title) {
    if (typeof window.settHandSideOverskrift === 'function') {
      try { window.settHandSideOverskrift(title); return; } catch (e) {}
    }
    var h = $('handSideOverskrift') || document.querySelector('#appSide h1');
    if (h) h.textContent = title || '';
  }

  function updateAdminVisibility() {
    var admin = isAdmin();
    var sys = isSysadmin();
    var group = $('adminMenyGruppe');
    var sysBtn = $('sysadminModeKnapp');
    admin ? showInline(group) : hide(group);
    sys ? showInline(sysBtn) : hide(sysBtn);

    // Ikke vis/skjul arbeidssider her. Det gjøres kun av showOnly().
    // Ellers vises alle admin-sider samtidig.
    document.querySelectorAll('.admin-only').forEach(function(el){
      if (el.id === 'adminMenyGruppe' || (el.closest && el.closest('#adminMenyGruppe'))) {
        admin ? showInline(el) : hide(el);
      }
    });
    document.querySelectorAll('.systemadmin-only').forEach(function(el){
      if (el.id === 'sysadminModeKnapp' || (el.closest && el.closest('#adminMenyGruppe'))) {
        sys ? showInline(el) : hide(el);
      }
    });
  }

  function hideAllSides() { SIDE_IDS.forEach(function(id){ hide($(id)); }); }

  function showOnly(sideId, title) {
    var app = $('appSide');
    show(app);
    if (app) app.style.removeProperty('visibility');
    updateAdminVisibility();
    hideAllSides();
    show($(sideId));
    setTitle(title);
    closeAdminMenu();
  }

  function call(name, delay) {
    if (typeof window[name] !== 'function') return;
    setTimeout(function(){ try { window[name](); } catch (e) { console.warn(name + ' feilet', e); } }, delay || 20);
  }
  function requireAdmin(msg) {
    if (isAdmin()) return true;
    alert(msg || 'Du har ikke tilgang til denne funksjonen.');
    closeAdminMenu();
    return false;
  }

  function visLogin() { show($('loginSide')); hide($('nyttPassordSide')); hide($('appSide')); closeAdminMenu(); }
  function visNyttPassord() { hide($('loginSide')); show($('nyttPassordSide')); hide($('appSide')); closeAdminMenu(); }

  async function visApp() {
    hide($('loginSide'));
    hide($('nyttPassordSide'));
    show($('appSide'));
    updateAdminVisibility();
    call('lastKunder', 10);
    call('lastProsjekter', 20);
    call('lastAnsatte', 30);
    call('settDagensDato', 40);
    call('lastTimer', 50);
    visTimerSide();
  }

  function visTimerSide() {
    showOnly('timerSide','Timeregistrering');
    if (isAdmin()) { show($('adminAnsattRad')); call('fyllAdminAnsattValg', 20); } else hide($('adminAnsattRad'));
    call('reparerBilvalg', 30);
  }
  function visJobberSide() { showOnly('jobberSide','Jobber'); call('lastJobber', 20); }
  function visFravaerSide() { showOnly('fravaerSide','Fravær / Flexi'); call('lastFravaerFlexi', 20); }
  function visMinBilSide() { showOnly('bilerSide','Min bil / fyll lager'); call('lastBiler',20); call('lastBilLager',40); call('fyllBilvalgTrygt',60); call('begrensBilLagerForVanligBruker',80); }

  function visKundeSide() { if (!requireAdmin('Du har ikke tilgang til kunder.')) return; showOnly('kundeSide','Kunder'); call('lastKunder',20); call('tegnKunder',40); call('tegnKundeListe',60); }
  function visTilbudSide() { if (!requireAdmin('Du har ikke tilgang til tilbud.')) return; showOnly('tilbudSide','Tilbud'); call('fyllTilbudKundeDropdown',20); call('lastTilbud',40); }
  function visFakturaSide() { if (!requireAdmin('Du har ikke tilgang til faktura.')) return; showOnly('fakturaSide','Faktura'); call('fyllOkonomiKundeValg',20); call('lastFaktura',40); }
  function visVarerSide() { if (!requireAdmin('Du har ikke tilgang til varer.')) return; showOnly('varerSide','Lager / Varer'); call('lastVarer',20); call('handLastVarer',40); call('lastVarelager',60); }
  function visAdminBilerSide() { if (!requireAdmin('Du har ikke tilgang til biler.')) return; showOnly('bilerSide','Biler / bil-lager'); call('lastBiler',20); call('lastBilLager',40); call('fyllBilvalgTrygt',60); }
  function visBilBestillingerSide() { if (!requireAdmin('Du har ikke tilgang til bestillinger.')) return; showOnly('bilBestillingerSide','Bestillinger'); call('handLastBilBestillinger',20); call('handLastAdminBilBestillinger',40); call('renderAdminBilBestillinger',60); call('rilVisBestillinger',80); }
  function visLonnSide() { if (!requireAdmin('Du har ikke tilgang til lønn.')) return; showOnly('lonnPanel','Lønn'); call('lastAnsatte',20); call('fyllLonnAnsattValg',60); }
  function visAnsattSide() { if (!requireAdmin('Du har ikke tilgang til ansatte.')) return; showOnly('ansattSide','Ansatte'); call('tegnTrekkListe',20); call('lastAnsatte',40); }
  function visFirmaSide() { if (!requireAdmin('Du har ikke tilgang til firma.')) return; showOnly('firmaSide','Firma'); call('lastFirma',20); call('fyllFirmaSkjema',40); call('tegnFirmaInfo',60); }
  function visBackupSide() { if (!requireAdmin('Du har ikke tilgang til backup.')) return; showOnly('backupSide','Backup / restore'); }
  function visTestSide() { if (!requireAdmin('Du har ikke tilgang til testpanel.')) return; showOnly('testSide','Testpanel'); }
  function visModulerSide() { if (!isSysadmin()) { alert('Moduler er kun for systemadmin.'); closeAdminMenu(); return; } showOnly('modulerSide','Moduler'); call('lastModulerFraDatabase',20); call('tegnModulGui',40); }

  var actions = {
    visTimerKnapp: visTimerSide,
    visJobberKnapp: visJobberSide,
    visFravaerKnapp: visFravaerSide,
    visBilerKnapp: visMinBilSide,
    visKundeKnapp: visKundeSide,
    visTilbudKnapp: visTilbudSide,
    visFakturaKnapp: visFakturaSide,
    visAdminVarerKnapp: visVarerSide,
    varerKnapp: visVarerSide,
    visAdminBilerKnapp: visAdminBilerSide,
    visBilBestillingerKnapp: visBilBestillingerSide,
    visLonnKnapp: visLonnSide,
    visAnsattKnapp: visAnsattSide,
    visFirmaKnapp: visFirmaSide,
    visBackupKnapp: visBackupSide,
    visTestKnapp: visTestSide,
    visModulerKnapp: visModulerSide
  };

  function runAction(id, event) {
    var fn = actions[id];
    if (!fn) return false;
    if (event) { event.preventDefault(); event.stopPropagation(); if (event.stopImmediatePropagation) event.stopImmediatePropagation(); }
    closeAdminMenu();
    fn();
    setTimeout(closeAdminMenu, 0);
    setTimeout(closeAdminMenu, 50);
    setTimeout(closeAdminMenu, 200);
    return false;
  }

  function bind() {
    updateAdminVisibility();
    var adminBtn = $('adminMenyKnapp');
    if (adminBtn) {
      adminBtn.type = 'button';
      adminBtn.onclick = function(e){ if (e) { e.preventDefault(); e.stopPropagation(); } return toggleAdminMenu(); };
    }
    Object.keys(actions).forEach(function(id){
      var b = $(id);
      if (!b) return;
      b.type = 'button';
      b.onclick = function(e){ return runAction(id, e); };
    });
  }

  document.addEventListener('click', function(e){
    var adminBtn = e.target && e.target.closest && e.target.closest('#adminMenyKnapp');
    if (adminBtn) return toggleAdminMenu(e);
    var btn = e.target && e.target.closest && e.target.closest('button');
    if (btn && actions[btn.id]) return runAction(btn.id, e);
    if (!(e.target && e.target.closest && e.target.closest('#adminMenyGruppe'))) closeAdminMenu();
  }, true);
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeAdminMenu(); }, true);

  window.visLogin = visLogin;
  window.visNyttPassord = visNyttPassord;
  window.visApp = visApp;
  window.oppdaterAdminVisning = updateAdminVisibility;
  window.visTimerSide = window.rilVisTimerSide = visTimerSide;
  window.visTimerForAnsattSide = window.rilVisTimerForAnsattSide = visTimerSide;
  window.visJobberSide = visJobberSide;
  window.visFravaerSide = visFravaerSide;
  window.visBilerSide = visMinBilSide;
  window.handOpenMinBil = visMinBilSide;
  window.handOpenMinBilHard = visMinBilSide;
  window.visKundeSide = visKundeSide;
  window.visTilbudSide = visTilbudSide;
  window.visFakturaSide = visFakturaSide;
  window.visVarerSide = visVarerSide;
  window.visBilBestillingerSide = visBilBestillingerSide;
  window.visLonnSide = visLonnSide;
  window.visAnsattSide = visAnsattSide;
  window.visFirmaSide = visFirmaSide;
  window.visBackupSide = visBackupSide;
  window.visTestSide = visTestSide;
  window.visModulerSide = visModulerSide;
  window.skjulArbeidssider = hideAllSides;
  window.skjulAlleSider = hideAllSides;
  window.rilCloseAdminMenuStable = closeAdminMenu;

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
  document.addEventListener('handPartialerLastet', function(){ setTimeout(bind,0); setTimeout(bind,100); });
  window.addEventListener('load', function(){ setTimeout(bind,0); setTimeout(bind,300); });
})();
