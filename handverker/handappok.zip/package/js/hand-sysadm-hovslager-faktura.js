/* Fjernet fra håndverkerappen. */
