/* Fjernet fra håndverkerappen. */
