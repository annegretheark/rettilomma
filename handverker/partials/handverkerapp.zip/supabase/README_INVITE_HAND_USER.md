# Invitasjon til håndverker-eier/admin

Denne versjonen bruker eksisterende Edge Function `opprett-hand-kunde` ved ny bedrift.

Knappen i Sysadm heter `Opprett og send invitasjon` og skal bare brukes når skjemaet er tomt / ny bedrift.

Funksjonen oppretter firma i `hand_firma`, sender Supabase Auth-invitasjon og lager adminrad i `hand_ansatt`.

Deploy ved behov:

```bash
supabase functions deploy opprett-hand-kunde
```

`invite-hand-user` brukes ikke av appen i denne flyten.
