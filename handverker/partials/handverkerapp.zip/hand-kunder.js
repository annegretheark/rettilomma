let kunder = [];
let prosjekter = [];


async function hentInnloggetFirmaIderForKunder() {
  if (!window.supabaseClient || !supabaseClient.auth) return [];

  const { data: userData, error: userError } = await supabaseClient.auth.getUser();
  const user = userData && userData.user ? userData.user : null;
  const email = String(
    (user && user.email) ||
    window.innloggetEpost ||
    localStorage.getItem("handInnloggetEpost") ||
    localStorage.getItem("innloggetEpost") ||
    ""
  ).trim().toLowerCase();

  if (userError || !user || !email) {
    console.error("Fant ikke innlogget bruker/epost ved henting av kunder:", userError);
    settKundeMelding("Fant ikke innlogget e-post. Logg ut og inn igjen.");
    return [];
  }

  const rolleFraMinne = String(window.innloggetRolle || localStorage.getItem("handInnloggetRolle") || "").toLowerCase();
  if (rolleFraMinne === "sysadmin" || rolleFraMinne === "systemadmin") {
    return ["__SYSADMIN_ALL__"];
  }

  // VIKTIG: I denne databasen er hand_ansatt.user_id ofte tom.
  // Derfor må firma til ansatt finnes via epost, ikke user_id.
  const ansattRes = await supabaseClient
    .from("hand_ansatt")
    .select("id, navn, epost, firma_id")
    .ilike("epost", email)
    .limit(1);

  if (!ansattRes.error && ansattRes.data && ansattRes.data.length && ansattRes.data[0].firma_id) {
    const firmaId = String(ansattRes.data[0].firma_id);
    window.aktivFirmaId = firmaId;
    window.handFirmaId = firmaId;
    window.handAnsattFirmaId = firmaId;
    localStorage.setItem("aktivFirmaId", firmaId);
    localStorage.setItem("handFirmaId", firmaId);
    localStorage.setItem("firma_id", firmaId);
    return [firmaId];
  }

  // Reserve hvis epost ikke finnes i hand_ansatt, men hand_firma_bruker er riktig.
  const fbRes = await supabaseClient
    .from("hand_firma_bruker")
    .select("firma_id")
    .eq("user_id", user.id);

  if (!fbRes.error && fbRes.data && fbRes.data.length) {
    const firmaIder = [...new Set((fbRes.data || []).map(r => String(r.firma_id || "")).filter(Boolean))];
    if (firmaIder.length === 1) {
      window.aktivFirmaId = firmaIder[0];
      window.handFirmaId = firmaIder[0];
      localStorage.setItem("aktivFirmaId", firmaIder[0]);
      localStorage.setItem("handFirmaId", firmaIder[0]);
      localStorage.setItem("firma_id", firmaIder[0]);
    }
    return firmaIder;
  }

  console.error("Fant ikke firma for kundevisning", { email, ansattError: ansattRes.error, firmaBrukerError: fbRes.error });
  settKundeMelding("Fant ikke ansatt/firma for " + email + ". Sjekk hand_ansatt.epost og firma_id.");
  return [];
}

function settKundeMelding(tekst) {
  const el = document.getElementById("kundeMelding");
  if (el) el.textContent = tekst || "";
}

async function lastKunder() {
  const firmaIder = await hentInnloggetFirmaIderForKunder();

  if (!firmaIder.length) {
    kunder = [];
    prosjekter = [];
    window.kunder = kunder;
    window.prosjekter = prosjekter;
    settKundeMelding("Innlogget bruker er ikke koblet til firma.");
    visKunder();
    fyllKundeDropdown();
    fyllFakturaKundeDropdown();
    return;
  }

  let kundeQuery = supabaseClient
    .from("hand_kunde")
    .select("*")
    .order("navn", { ascending: true });

  const erSysadminAlle = firmaIder.includes("__SYSADMIN_ALL__");
  if (!erSysadminAlle) {
    kundeQuery = kundeQuery.in("firma_id", firmaIder);
  }

  const { data, error } = await kundeQuery;

  if (error) {
    console.error("Feil ved henting av kunder:", error);
    settKundeMelding("Feil ved henting av kunder: " + error.message);
    return;
  }

  kunder = erSysadminAlle
    ? (data || [])
    : (data || []).filter(k => firmaIder.map(String).includes(String(k.firma_id)));
  window.kunder = kunder;

  const kundeIder = kunder.map(k => k.id).filter(Boolean);

  if (kundeIder.length) {
    const prosjektResult = await supabaseClient
      .from("hand_prosjekt")
      .select("*")
      .in("kunde_id", kundeIder)
      .order("navn", { ascending: true });

    prosjekter = prosjektResult.error ? [] : prosjektResult.data || [];
  } else {
    prosjekter = [];
  }

  window.prosjekter = prosjekter;

  visKunder();
  fyllKundeDropdown();
  fyllFakturaKundeDropdown();
}

async function lagreKunde() {
  const id = document.getElementById("kundeId")?.value || "";

  const firmaIder = await hentInnloggetFirmaIderForKunder();
  const firmaId = firmaIder.length === 1
    ? firmaIder[0]
    : (
        localStorage.getItem('handFirmaId') ||
        localStorage.getItem('aktivFirmaId') ||
        window.handFirmaId ||
        ''
      );

  const kunde = {
    navn: document.getElementById("kundeNavn").value.trim(),
    adresse: document.getElementById("kundeAdresse").value.trim(),
    epost: document.getElementById("kundeEpost").value.trim(),
    kontaktperson: document.getElementById("kundeKontaktperson").value.trim(),
    kontonr: document.getElementById("kundeKontonr").value.trim(),
    firma_id: firmaId || null
  };

  if (!firmaId) {
    settKundeMelding("Velg firma før kunde lagres.");
    return;
  } ;

  if (!kunde.navn) {
    settKundeMelding("Kundenavn må fylles ut.");
    return;
  }

  const result = id
    ? await supabaseClient.from("hand_kunde").update(kunde).eq("id", id).select()
    : await supabaseClient.from("hand_kunde").insert([kunde]).select();

  if (result.error) {
    settKundeMelding("Feil ved lagring av kunde: " + result.error.message);
    return;
  }

  // RIL FIX 7088:
  // Etter lagring skal kundeskjemaet bli blankt, klart for neste kunde.
  settKundeMelding("Kunde lagret.");

  await lastKunder();

  nullstillKundeSkjema();

  // Behold meldingen etter nullstilling.
  settKundeMelding("Kunde lagret. Skjemaet er klart for ny kunde.");
}

function visProsjektVindu() {
  const kundeId = document.getElementById("kundeId")?.value || "";

  if (!kundeId) {
    settKundeMelding("Lagre eller velg kunde først.");
    return;
  }

  const overlay = document.getElementById("prosjektOverlay");
  const vindu = document.getElementById("prosjektVindu");

  if (overlay) overlay.style.display = "block";
  if (vindu) vindu.style.display = "block";

  nullstillProsjektFelter();
}

function skjulProsjektVindu() {
  const overlay = document.getElementById("prosjektOverlay");
  const vindu = document.getElementById("prosjektVindu");

  if (overlay) overlay.style.display = "none";
  if (vindu) vindu.style.display = "none";

  nullstillProsjektFelter();
}

function nullstillProsjektFelter() {
  const prosjektNr = document.getElementById("prosjektNr");
  const prosjektNavn = document.getElementById("prosjektNavn");
  const prosjektBeskrivelse = document.getElementById("prosjektBeskrivelse");

  if (prosjektNr) prosjektNr.value = "";
  if (prosjektNavn) prosjektNavn.value = "";
  if (prosjektBeskrivelse) prosjektBeskrivelse.value = "";
}

async function lagreProsjektForValgtKunde() {
  const kundeId = document.getElementById("kundeId")?.value || "";

  if (!kundeId) {
    settKundeMelding("Lagre eller velg kunde først.");
    return;
  }

  const prosjektNr = document.getElementById("prosjektNr")?.value?.trim() || "";
  const prosjektNavn = document.getElementById("prosjektNavn")?.value?.trim() || "";
  const prosjektBeskrivelse = document.getElementById("prosjektBeskrivelse")?.value?.trim() || "";

  if (!prosjektNr && !prosjektNavn) {
    settKundeMelding("Fyll ut prosjektnr eller prosjektnavn.");
    return;
  }

  const { error } = await supabaseClient
    .from("hand_prosjekt")
    .insert([{
      kunde_id: kundeId,
      prosjektnr: prosjektNr,
      navn: prosjektNavn,
      beskrivelse: prosjektBeskrivelse,
      aktiv: true
    }]);

  if (error) {
    console.error("Feil ved lagring av prosjekt:", error);
    settKundeMelding("Feil ved lagring av prosjekt: " + error.message);
    return;
  }

  nullstillProsjektFelter();
  skjulProsjektVindu();

  await lastKunder();

  const valgtKunde = kunder.find(k => String(k.id || "") === String(kundeId || ""));
  if (valgtKunde) {
    document.getElementById("kundeId").value = valgtKunde.id || "";
    document.getElementById("kundeNavn").value = valgtKunde.navn || "";
    document.getElementById("kundeAdresse").value = valgtKunde.adresse || "";
    document.getElementById("kundeEpost").value = valgtKunde.epost || "";
    document.getElementById("kundeKontaktperson").value = valgtKunde.kontaktperson || "";
    document.getElementById("kundeKontonr").value = valgtKunde.kontonr || "";
  } else {
    document.getElementById("kundeId").value = kundeId;
  }

  settKundeMelding("Prosjekt lagret. Du trenger ikke lagre kunde på nytt.");
}

function visKunder() {
  const liste = document.getElementById("kundeListe");
  if (!liste) return;

  liste.innerHTML = "";

  if (!kunder.length) {
    liste.innerHTML = "<p>Ingen kunder funnet.</p>";
    return;
  }

  kunder.forEach(kunde => {
    const div = document.createElement("div");
    div.className = "card";
    div.style.padding = "14px";
    div.style.marginBottom = "14px";
    div.style.borderBottom = "1px solid #444";

    const kundeProsjekter = prosjekter.filter(p =>
      String(p.kunde_id || "") === String(kunde.id || "")
    );

    const prosjektHtml = kundeProsjekter.length
      ? `
        <div style="margin-top:10px;">
          <strong>Prosjekter:</strong>
          <ul style="margin-top:6px;">
            ${kundeProsjekter.map(p => `
              <li>
                ${p.prosjektnr || ""} ${p.navn || ""}
                ${p.beskrivelse ? `<br><small>${p.beskrivelse}</small>` : ""}
              </li>
            `).join("")}
          </ul>
        </div>
      `
      : `
        <div style="margin-top:10px;">
          <em>Ingen prosjekter</em>
        </div>
      `;

    div.innerHTML = `
      <div style="line-height:1.35;">
        <strong>${kunde.navn || ""}</strong><br>
        Kundenr: ${kunde.kundenr || kunde.kunde_nr || ""}<br>
        ${kunde.adresse || ""}<br>
        ${kunde.epost || ""}<br>
        ${kunde.kontaktperson || ""}<br>
        ${kunde.kontonr || ""}
      </div>

      <div style="margin-top:10px; margin-bottom:4px;">
        <button
          type="button"
          class="secondary"
          onclick="redigerKunde('${kunde.id}')">
          Rediger
        </button>
      </div>

      ${prosjektHtml}
    `;

    liste.appendChild(div);
  });
}


function redigerKunde(id) {
  const kunde = kunder.find(k => String(k.id) === String(id));

  if (!kunde) {
    alert("Fant ikke kunde");
    return;
  }

  document.getElementById("kundeId").value = kunde.id;
  document.getElementById("kundeNavn").value = kunde.navn || "";
  document.getElementById("kundeAdresse").value = kunde.adresse || "";
  document.getElementById("kundeEpost").value = kunde.epost || "";
  document.getElementById("kundeKontaktperson").value = kunde.kontaktperson || "";
  document.getElementById("kundeKontonr").value = kunde.kontonr || "";

  nullstillProsjektFelter();
  skjulProsjektVindu();

  settKundeMelding("Redigerer kunde. Du kan legge til flere prosjekter.");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function nullstillKundeSkjema() {
  document.getElementById("kundeId").value = "";
  document.getElementById("kundeNavn").value = "";
  document.getElementById("kundeAdresse").value = "";
  document.getElementById("kundeEpost").value = "";
  document.getElementById("kundeKontaktperson").value = "";
  document.getElementById("kundeKontonr").value = "";

  nullstillProsjektFelter();
  skjulProsjektVindu();
  settKundeMelding("");
}

function hentKundeNr(kunde) {
  return kunde?.kundenr || kunde?.kunde_nr || "";
}

function finnKundeFraValg(verdi) {
  return kunder.find(k =>
    String(k.id || "") === String(verdi) ||
    String(k.kundenr || "") === String(verdi) ||
    String(k.kunde_nr || "") === String(verdi)
  );
}

function fyllKundeDropdown() {
  const valg = document.getElementById("kundeValg");
  if (!valg) return;

  valg.innerHTML = "";

  const tomOption = document.createElement("option");
  tomOption.value = "";
  tomOption.textContent = "Velg kunde";
  tomOption.selected = true;

  valg.appendChild(tomOption);

  kunder.forEach(kunde => {
    const option = document.createElement("option");
    option.value = kunde.id;
    option.textContent = kunde.navn || "";
    valg.appendChild(option);
  });

  valg.selectedIndex = 0;
  valg.value = "";

  const kundeNrVisning = document.getElementById("kundeNrVisning");
  if (kundeNrVisning) kundeNrVisning.value = "";
}

function fyllFakturaKundeDropdown() {
  const valg = document.getElementById("fakturaKundeValg");
  if (!valg) return;

  const gammelVerdi = valg.value || "";

  valg.innerHTML = "";

  const tomOption = document.createElement("option");
  tomOption.value = "";
  tomOption.textContent = "Velg kunde";
  valg.appendChild(tomOption);

  kunder.forEach(kunde => {
    const option = document.createElement("option");
    option.value = kunde.id;
    const nr = kunde.kundenr || kunde.kunde_nr || kunde.id || "";
    option.textContent = nr ? nr + " - " + (kunde.navn || "") : (kunde.navn || "");
    valg.appendChild(option);
  });

  if (gammelVerdi) {
    valg.value = gammelVerdi;
  }
}

function visKundeNavn() {
  const valg = document.getElementById("kundeValg");
  if (!valg) return;

  const kunde = finnKundeFraValg(valg.value);
  const nrVisning = document.getElementById("kundeNrVisning");

  if (nrVisning) {
    nrVisning.value = kunde ? hentKundeNr(kunde) : "";
  }
}

window.kunder = kunder;
window.prosjekter = prosjekter;

window.lastKunder = lastKunder;
window.fyllFakturaKundeDropdown = fyllFakturaKundeDropdown;
window.lagreKunde = lagreKunde;
window.redigerKunde = redigerKunde;
window.nullstillKundeSkjema = nullstillKundeSkjema;

window.visProsjektVindu = visProsjektVindu;
window.skjulProsjektVindu = skjulProsjektVindu;
window.lagreProsjektForValgtKunde = lagreProsjektForValgtKunde;

window.fyllKundeDropdown = fyllKundeDropdown;
window.visKundeNavn = visKundeNavn;
window.hentKundeNr = hentKundeNr;
window.finnKundeFraValg = finnKundeFraValg;

window.tegnKundeListe = visKunder;
window.tegnKunder = fyllKundeDropdown;

/* RIL FINAL FIX 20260623
   - Rediger-knapp vises for systemadmin-rolle, sysadmin, systemadmin og admin.
   - Kundenr lages automatisk ved ny kunde.
   - Prosjektnr lages automatisk som kundenr + '-' + løpenr, f.eks. 1001-1, 1001-2.
*/
(function(){
  'use strict';
  if(window.__rilKundeRedigerAutoNrFinal) return;
  window.__rilKundeRedigerAutoNrFinal = true;

  function $(id){ return document.getElementById(id); }
  function s(v){ return String(v == null ? '' : v); }
  function esc(v){ return s(v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function numOnly(v){ return s(v).replace(/[^0-9]/g,''); }
  function client(){ return window.supabaseClient || window.supabase || null; }
  function rolle(){ return s(window.innloggetRolle || localStorage.getItem('handInnloggetRolle') || localStorage.getItem('innloggetRolle')).toLowerCase(); }
  function innloggetEpost(){ return s(window.innloggetEpost || window.handInnloggetEpost || localStorage.getItem('handInnloggetEpost') || localStorage.getItem('innloggetEpost') || localStorage.getItem('email')).trim().toLowerCase(); }

  // Bare admin i eget firma skal kunne redigere kunder.
  // Vanlig bruker/håndverker får ikke Rediger-knapp.
  var firmaAdminCacheKey = '';
  var firmaAdminCacheValue = false;
  function erGlobalAdmin(){
    var r=rolle();
    return r.indexOf('sysadmin')>=0 || r.indexOf('systemadmin')>=0 || s(localStorage.getItem('rilSysadminModus')).toLowerCase()==='true';
  }
  function harAdminRolleVerdi(v){
    var r=s(v).toLowerCase().replace(/\s+/g,'');
    return r==='admin' || r==='firmaadmin' || r==='firma_admin' || r==='administrator' || r==='eier' || r==='owner' || r==='dagligleder' || r==='daglig_leder';
  }
  function harAdminKnappIDom(){
    try{
      var els=[].slice.call(document.querySelectorAll('button,a,[role=button]'));
      return els.some(function(el){
        var t=s(el.textContent).toLowerCase().replace(/\s+/g,' ').trim();
        return t==='admin' || t==='admin ▼' || t.indexOf('admin')===0;
      });
    }catch(e){ return false; }
  }
  function radErFirmaAdmin(rad){
    if(!rad) return false;
    if(rad.er_admin === true || rad.admin === true || rad.is_admin === true || rad.firma_admin === true || rad.kan_administrere === true) return true;
    return harAdminRolleVerdi(rad.rolle) || harAdminRolleVerdi(rad.role) || harAdminRolleVerdi(rad.tilgang) || harAdminRolleVerdi(rad.type);
  }
  function kanRedigereKunder(){
    if(erGlobalAdmin()) return true;
    if(harAdminRolleVerdi(rolle())) return true;
    if(harAdminKnappIDom()) return true;
    return firmaAdminCacheValue === true;
  }
  async function oppdaterFirmaAdminTilgang(){
    if(erGlobalAdmin()) { firmaAdminCacheValue = true; return true; }
    var c=client();
    var e=innloggetEpost();
    var f=await firmaId();
    var key=e+'|'+s(f);
    if(key && key===firmaAdminCacheKey) return firmaAdminCacheValue;
    firmaAdminCacheKey=key;
    firmaAdminCacheValue=false;
    if(!c || !e || !f || f==='__SYSADMIN_ALL__') return false;
    try{
      var r=await c.from('hand_ansatt').select('*').ilike('epost',e).eq('firma_id',f).limit(1);
      if(!r.error && r.data && r.data.length) firmaAdminCacheValue = radErFirmaAdmin(r.data[0]);
    }catch(err){
      console.warn('Kunne ikke sjekke firma-admin for kunder:', err);
    }
    return firmaAdminCacheValue;
  }
  function msg(t){ var el=$('kundeMelding'); if(el) el.textContent=t||''; }
  function getKunder(){ return window.kunder || []; }
  function getProsjekter(){ return window.prosjekter || []; }
  function kundenr(k){ return s(k && (k.kundenr || k.kunde_nr || k.kundenummer || k.nr)); }
  function prosjektnr(p){ return s(p && (p.prosjektnr || p.prosjekt_nr || p.prosjektNr || p.nr)); }

  async function firmaId(){
    try{ if(typeof window.hentAktivFirmaId === 'function') return await window.hentAktivFirmaId(); }catch(e){}
    return window.aktivFirmaId || window.handFirmaId || localStorage.getItem('aktivFirmaId') || localStorage.getItem('handFirmaId') || localStorage.getItem('firma_id') || null;
  }
  async function safeInsert(table, row){
    var c=client(), data=Object.assign({},row);
    for(var i=0;i<40;i++){
      var r=await c.from(table).insert([data]).select();
      if(!r.error) return r;
      var m=s(r.error.message);
      var col=(m.match(/Could not find the '([^']+)' column/i)||[])[1] || (m.match(/column "([^"]+)".*does not exist/i)||[])[1];
      if(col && Object.prototype.hasOwnProperty.call(data,col)){ delete data[col]; continue; }
      return r;
    }
  }
  async function safeUpdate(table, id, row){
    var c=client(), data=Object.assign({},row);
    for(var i=0;i<40;i++){
      var r=await c.from(table).update(data).eq('id',id).select();
      if(!r.error) return r;
      var m=s(r.error.message);
      var col=(m.match(/Could not find the '([^']+)' column/i)||[])[1] || (m.match(/column "([^"]+)".*does not exist/i)||[])[1];
      if(col && Object.prototype.hasOwnProperty.call(data,col)){ delete data[col]; continue; }
      return r;
    }
  }
  function nesteKundenr(){
    var max=0;
    getKunder().forEach(function(k){ var n=parseInt(numOnly(kundenr(k)),10); if(Number.isFinite(n) && n>max) max=n; });
    return String(max ? max+1 : 1001);
  }
  function nesteProsjektNrForKunde(kunde){
    var base=kundenr(kunde) || s($('kundeNrVis')&&$('kundeNrVis').value) || s($('kundeNr')&&$('kundeNr').value) || nesteKundenr();
    base=s(base).replace(/\s+/g,'');
    var prefix=base+'-';
    var max=0;
    var valgtKundeId=s(kunde && kunde.id || $('kundeId') && $('kundeId').value);
    getProsjekter().filter(function(p){ return s(p.kunde_id)===valgtKundeId; }).forEach(function(p){
      var pn=prosjektnr(p);
      var part = pn.indexOf(prefix)===0 ? pn.slice(prefix.length) : pn.split('-').pop();
      var n=parseInt(numOnly(part),10); if(Number.isFinite(n)&&n>max) max=n;
    });
    return prefix + String(max+1);
  }
  function fillKundeForm(k){
    if(!$('kundeId')) return;
    $('kundeId').value = k && k.id || '';
    if($('kundeNr')) $('kundeNr').value = k ? kundenr(k) : '';
    if($('kundeNrVis')) $('kundeNrVis').value = k ? kundenr(k) : '(lages automatisk)';
    if($('kundeNavn')) $('kundeNavn').value = k && k.navn || '';
    if($('kundeAdresse')) $('kundeAdresse').value = k && k.adresse || '';
    if($('kundeEpost')) $('kundeEpost').value = k && k.epost || '';
    if($('kundeKontaktperson')) $('kundeKontaktperson').value = k && k.kontaktperson || '';
    if($('kundeKontonr')) $('kundeKontonr').value = k && k.kontonr || '';
    if($('leggTilKundeKnapp')) $('leggTilKundeKnapp').textContent = k ? 'Lagre endringer' : 'Lagre kunde';
    var avbryt=$('avbrytKundeRedigeringKnapp'); if(avbryt) avbryt.style.display = k ? '' : 'none';
  }
  window.redigerKunde = function(id){
    if(!kanRedigereKunder()){ alert('Du mangler redigeringstilgang til kunder.'); return; }
    var k=getKunder().find(function(x){return s(x.id)===s(id);});
    if(!k){ alert('Fant ikke kunde'); return; }
    fillKundeForm(k);
    if(typeof window.skjulProsjektVindu==='function') window.skjulProsjektVindu();
    msg('Redigerer kunde. Trykk Lagre endringer når du er ferdig.');
    var side=$('kundeSide'); if(side) side.scrollIntoView({behavior:'smooth',block:'start'});
  };
  window.nullstillKundeSkjema = function(){
    fillKundeForm(null);
    if($('kundeNrVis')) $('kundeNrVis').value='(lages automatisk)';
    if(typeof window.skjulProsjektVindu==='function') window.skjulProsjektVindu();
    msg('');
  };
  window.lagreKunde = async function(){
    var c=client(); if(!c){ msg('Supabase er ikke lastet.'); return; }
    var id=s($('kundeId')&&$('kundeId').value);
    var navn=s($('kundeNavn')&&$('kundeNavn').value).trim();
    if(!navn){ msg('Kundenavn må fylles ut.'); return; }
    var nr = id ? s(($('kundeNr')&&$('kundeNr').value) || ($('kundeNrVis')&&$('kundeNrVis').value)) : nesteKundenr();
    nr=s(nr).replace(/[^0-9A-Za-z_-]/g,'');
    var data={
      navn:navn,
      adresse:s($('kundeAdresse')&&$('kundeAdresse').value).trim(),
      epost:s($('kundeEpost')&&$('kundeEpost').value).trim(),
      kontaktperson:s($('kundeKontaktperson')&&$('kundeKontaktperson').value).trim(),
      kontonr:s($('kundeKontonr')&&$('kundeKontonr').value).trim(),
      kundenr:nr,
      kunde_nr:nr,
      firma_id:await firmaId()
    };
    var r=id ? await safeUpdate('hand_kunde', id, data) : await safeInsert('hand_kunde', data);
    if(r && r.error){ msg('Feil ved lagring av kunde: '+r.error.message); return; }
    msg(id ? 'Kunde endret.' : 'Kunde lagret med kundenr '+nr+'.');
    if(typeof window.lastKunder==='function') await window.lastKunder();
    window.nullstillKundeSkjema();
  };
  window.visProsjektVindu = function(){
    var id=s($('kundeId')&&$('kundeId').value);
    if(!id){ msg('Trykk Rediger på kunden først, eller lagre kunden før du legger til prosjekt.'); return; }
    var k=getKunder().find(function(x){return s(x.id)===id;});
    var pn=nesteProsjektNrForKunde(k);
    if($('prosjektNr')) $('prosjektNr').value=pn;
    var overlay=$('prosjektOverlay'), vindu=$('prosjektVindu');
    if(overlay) overlay.style.display='block';
    if(vindu) vindu.style.display='block';
  };
  window.lagreProsjektForValgtKunde = async function(){
    var c=client(); if(!c){ msg('Supabase er ikke lastet.'); return; }
    var kundeId=s($('kundeId')&&$('kundeId').value);
    if(!kundeId){ msg('Velg kunde med Rediger først.'); return; }
    var k=getKunder().find(function(x){return s(x.id)===kundeId;});
    var pn=s($('prosjektNr')&&$('prosjektNr').value).trim() || nesteProsjektNrForKunde(k);
    var navn=s($('prosjektNavn')&&$('prosjektNavn').value).trim();
    var bes=s($('prosjektBeskrivelse')&&$('prosjektBeskrivelse').value).trim();
    if(!navn){ msg('Fyll ut prosjektnavn.'); return; }
    var data={kunde_id:kundeId, prosjektnr:pn, prosjekt_nr:pn, navn:navn, beskrivelse:bes, aktiv:true, firma_id:k&&k.firma_id || await firmaId()};
    var r=await safeInsert('hand_prosjekt', data);
    if(r && r.error){ msg('Feil ved lagring av prosjekt: '+r.error.message); return; }
    msg('Prosjekt lagret med prosjektnr '+pn+'.');
    if($('prosjektNavn')) $('prosjektNavn').value='';
    if($('prosjektBeskrivelse')) $('prosjektBeskrivelse').value='';
    if(typeof window.skjulProsjektVindu==='function') window.skjulProsjektVindu();
    if(typeof window.lastKunder==='function') await window.lastKunder();
    fillKundeForm(k || getKunder().find(function(x){return s(x.id)===kundeId;}));
  };
  function renderKunderMedRediger(){
    var liste=$('kundeListe'); if(!liste) return;
    var ks=getKunder(), ps=getProsjekter();
    if(!ks.length){ liste.innerHTML='<p>Ingen kunder funnet.</p>'; return; }
    liste.innerHTML=ks.map(function(k){
      var kps=ps.filter(function(p){return s(p.kunde_id)===s(k.id);});
      return '<div class="card" style="padding:14px;margin-bottom:14px;border-bottom:1px solid #444">'
        +'<div style="line-height:1.35"><strong>'+esc(k.navn||'')+'</strong><br>Kundenr: '+esc(kundenr(k))+'<br>'+esc(k.adresse||'')+'<br>'+esc(k.epost||'')+'<br>'+esc(k.kontaktperson||'')+'<br>'+esc(k.kontonr||'')+'</div>'
        +(kanRedigereKunder()?'<div style="margin-top:10px"><button type="button" class="secondary ril-rediger-kunde" data-id="'+esc(k.id)+'">Rediger</button></div>':'')
        +'<div style="margin-top:10px"><strong>Prosjekter:</strong>'+(kps.length?'<ul style="margin-top:6px">'+kps.map(function(p){return '<li>'+esc(prosjektnr(p))+' '+esc(p.navn||'')+(p.beskrivelse?'<br><small>'+esc(p.beskrivelse)+'</small>':'')+'</li>';}).join('')+'</ul>':'<div><em>Ingen prosjekter</em></div>')+'</div>'
        +'</div>';
    }).join('');
    liste.querySelectorAll('.ril-rediger-kunde').forEach(function(b){ b.onclick=function(){ window.redigerKunde(b.dataset.id); }; });
  }
  var oldLast=window.lastKunder;
  window.lastKunder=async function(){ if(typeof oldLast==='function') await oldLast.apply(this,arguments); await oppdaterFirmaAdminTilgang(); renderKunderMedRediger(); };
  window.tegnKundeListe=renderKunderMedRediger;
  window.visKunder=renderKunderMedRediger;
  function forsinketRender(ms){
    setTimeout(async function(){
      if($('kundeNrVis')) $('kundeNrVis').value='(lages automatisk)';
      await oppdaterFirmaAdminTilgang();
      renderKunderMedRediger();
    }, ms);
  }
  document.addEventListener('handPartialerLastet',function(){ forsinketRender(300); forsinketRender(1000); forsinketRender(2500); });
  document.addEventListener('DOMContentLoaded',function(){ forsinketRender(500); forsinketRender(1500); forsinketRender(3000); });
})();


/* RIL HOTFIX 20260624
   Viser Rediger-knapp for firma-admin uten konsoll.
   Sjekker Admin-knappen i toppen og legger knappen inn også hvis gammel kundeliste allerede er tegnet.
*/
(function(){
  "use strict";
  if (window.__rilKundeRedigerKnappHotfix20260624) return;
  window.__rilKundeRedigerKnappHotfix20260624 = true;

  function s(v){ return String(v == null ? "" : v); }

  function harAdminMeny(){
    try {
      var el = Array.from(document.querySelectorAll("button,a,[role='button']"));
      return el.some(function(x){
        var t = s(x.textContent).toLowerCase().replace(/\s+/g, " ").trim();
        return t === "admin" || t === "admin ▼" || t.indexOf("admin") === 0;
      });
    } catch(e) {
      return false;
    }
  }

  function erAdmin(){
    var rolle = s(window.innloggetRolle || localStorage.getItem("handInnloggetRolle") || localStorage.getItem("innloggetRolle")).toLowerCase();
    if (rolle.indexOf("admin") >= 0 || rolle.indexOf("systemadmin") >= 0 || rolle.indexOf("sysadmin") >= 0) return true;
    return harAdminMeny();
  }

  function finnKundeIdFraKort(kort, indeks){
    var kunder = window.kunder || [];
    if (kunder[indeks] && kunder[indeks].id) return kunder[indeks].id;

    var tekst = s(kort.textContent).toLowerCase();
    var funnet = kunder.find(function(k){
      return k && k.id && k.navn && tekst.indexOf(s(k.navn).toLowerCase()) >= 0;
    });

    return funnet && funnet.id ? funnet.id : "";
  }

  function leggInnRedigerKnapper(){
    if (!erAdmin()) return;

    var liste = document.getElementById("kundeListe");
    if (!liste) return;

    var kort = Array.from(liste.children).filter(function(el){
      return el && el.nodeType === 1 && s(el.textContent).trim();
    });

    kort.forEach(function(el, indeks){
      if (el.querySelector(".ril-rediger-kunde")) return;

      var kundeId = finnKundeIdFraKort(el, indeks);
      if (!kundeId) return;

      var rad = document.createElement("div");
      rad.style.marginTop = "10px";

      var knapp = document.createElement("button");
      knapp.type = "button";
      knapp.className = "secondary ril-rediger-kunde";
      knapp.textContent = "Rediger";
      knapp.setAttribute("data-id", kundeId);
      knapp.onclick = function(){
        if (typeof window.redigerKunde === "function") {
          window.redigerKunde(kundeId);
        }
      };

      rad.appendChild(knapp);
      el.appendChild(rad);
    });
  }

  function start(){
    leggInnRedigerKnapper();
    setTimeout(leggInnRedigerKnapper, 300);
    setTimeout(leggInnRedigerKnapper, 1000);
    setTimeout(leggInnRedigerKnapper, 2500);

    var liste = document.getElementById("kundeListe");
    if (liste && window.MutationObserver) {
      var obs = new MutationObserver(function(){
        setTimeout(leggInnRedigerKnapper, 50);
      });
      obs.observe(liste, { childList:true, subtree:true });
    }
  }

  document.addEventListener("DOMContentLoaded", start);
  document.addEventListener("handPartialerLastet", start);
  setTimeout(start, 1500);
})();

